PANAGRAM AND PALINDROME
-----------------------
import java.util.Arrays;
import java.util.Scanner;

public class Palindrome 
{
public static void main(String args[])
{
	System.out.println("enter string");
	Scanner sc= new Scanner(System.in);
	

	String original, reverse = "";
   
    original = sc.nextLine();

    int length = original.length();

    for ( int i = length - 1; i >= 0; i-- )
       reverse = reverse + original.charAt(i);

    if (original.equals(reverse))
       System.out.println("Entered string is a palindrome.");
    else
       System.out.println("Entered string is not a palindrome.");

	
	boolean f=true;
	if(original.length()<26)
	{
		System.out.println("not panagram");	
	}
	else{
	for(char p='a';p<='z';p++)
	{
		if(original.contains(""+p))
		{
			
			f=true;
		}
	}
	
	if(f==true){
		System.out.println("yes,it's panagram");
	}
	
}
}
}
----------------------------------
CALENDAR
---
import java.util.Scanner;

public class Calenderq 
{
public static void main(String args[])
{
	System.out.println("enter number of days in month:");
	Scanner sc= new Scanner(System.in);
	int n=sc.nextInt();
	System.out.println("enter the start day number for month:");
	int d=sc.nextInt();
	if((n==30||n==31||n==28||n==29) && d<7)
	{
		
		
		
	System.out.println("M\t"+"T\t" + "W\t" + "T\t" + "F\t" + "S\t" + "S\t");
	for(int i=2;i<=d;i++)
	{
		System.out.print(" \t");
	}
	int k=1;
	while(k<=n)
	{
		for(int i=1;i<=7;i++)
		{while(k<=n){
			for(int j=d;j<=7;j++)
			{ if(k<=n){
				System.out.print(k+" \t");
				k++;}
				
			}
			
			System.out.println();
			d=1;
		}
		}
	}
	}
	
	else
	{
		System.out.println("ërror");
	}
	
}
}
---------------------------
SORTING USI
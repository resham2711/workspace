SET SERVEROUTPUT ON;

DECLARE
cursor mycur is select * from EMP where DEPTID=901;
BEGIN
	for emp_rec in mycur
	LOOP
	DBMS_OUTPUT.PUT_LINE(emp_rec.empid || ' ' || emp_rec.empname);
	END LOOP;
END;

--------------------------------------

DECLARE
    TYPE mytype IS REF CURSOR;     
    mycur mytype;                   
    emp_rec emp%rowtype;
    dept_rec department%rowtype;
BEGIN
 OPEN mycur for select * from emp where deptid=901;
   LOOP
    fetch mycur into emp_rec;         
    exit when mycur%notfound;       
    DBMS_OUTPUT.PUT_LINE(emp_rec.empid || ' ' || emp_rec.empname);  
   END LOOP;
  close mycur;  

  OPEN mycur for select * from department;
   LOOP
    fetch mycur into dept_rec;         
    exit when mycur%notfound;       
    DBMS_OUTPUT.PUT_LINE(dept_rec.dept_id || ' ' || dept_rec.dept_name);  
   END LOOP;
   close mycur;
END;

  
--------------------------------------------
   
  create table audittemp(num varchar(20));
  
  create or replace procedure
  get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number) IS
  BEGIN
    select empname,deptid into s_name,s_sal
    from emp
    where empid=s_code;
    EXCEPTION
      when no_data_found then
      insert into audittemp
      values('No employee with id' || s_code);
      s_name := null;
      s_sal := null;
      end get_details_16056;
   
   
  
      variable name1 varchar2(20);
      variable did number;
   
      execute get_details_16056(104, :name1, :did);
      print name1;
      print did;
--------------------------------------------
create or replace function crt_dept_16056(dno number,
   dname varchar2) RETURN   NUMBER 
   AS
   BEGIN 
    INSERT into department 
    values(dno,dname);
    return 1;
  EXCEPTION
    WHEN others THEN
    return 0;
    END crt_dept_16056;
    
    variable flag number;
    EXECUTE :flag:=crt_dept_16056(12,'production');
    print flag;
-----------------------------------------
create or replace package pckg_16056 AS
   procedure get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number);
   function crt_dept_16056 (dno number,
          dname varchar2) RETURN   NUMBER;
END pckg_16056;



create or replace package body pckg_16056 
    AS
      procedure get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number) IS
        BEGIN
          select empname,deptid into s_name,s_sal
          from emp
          where empid=s_code;
            EXCEPTION
              when no_data_found then
              insert into audittemp
              values('No employee with id' || s_code);
              s_name := null;
              s_sal := null;
      end get_details_16056;
      
      function crt_dept_16056(dno number,
          dname varchar2) RETURN   NUMBER 
          AS
             BEGIN 
              INSERT into department 
              values(dno,dname);
              return 1;
                  EXCEPTION
                    WHEN others THEN
                    return 0;
     END crt_dept_16056;
end pckg_16056;


variable name1 varchar2(20);
variable did number;
execute pckg_16056.get_details_16056(104, :name1, :did);
      print name1;
      print did;

variable flag number;
    EXECUTE :flag:=pckg_16056.crt_dept_16056(66,'prodn');
    print flag;
--------------------------------------------------------------
q1) return the cost of company using function
create table emp_16056 (emp_id number(2)not null,salary number(4),years number(2),primary key(emp_id));
insert into emp_16056 values (1,1000,1);
insert into emp_16056 values (2,2000,2);
insert into emp_16056 values (3,3000,3);
insert into emp_16056 values (4,4000,4);
insert into emp_16056 values (5,5000,5);
insert into emp_16056 values (6,1000,5);
update emp_16056 set years=1 where emp_id=3;
create or replace function sal_16056(emp_num number) RETURN   NUMBER 
   AS
   da number(5,2):= 0.15;
   hra number(5,2):= 0.20;
   ta number(5,2):=0.08;
   sa number(5,2);
   sall emp_16056.salary%TYPE := 0.00;
   yr emp_16056.years%TYPE;
   BEGIN
    select salary,years into sall,yr 
    from emp_16056 
    where emp_id=emp_num;
   if yr < 1
   then sa :=0;
   
   elsif yr >= 1 and  yr < 2 then
   sa := 0.1 * sall;
   
   elsif yr >= 2 and yr < 4 then
   sa := 0.2 * sall;
   
   elsif yr >= 4 then
   sa := 0.30 * sall;
   
   end if;
   sall := sall + sa + da * sall + hra * sall + ta * sall;
  return sall; 
   EXCEPTION 
       when no_data_found then
       return 0;
end sal_16056;
  
  variable flag number;
    EXECUTE :flag:=sal_16056(6);
    print flag;
--------------------------------------------------
q5) for all records at once
Create or replace procedure abbcx1
is
exp number:=0;
namee varchar(10);
sall emp_1605.salary%type;
emp_rec1 emp_1605%rowtype;
cursor mycur is 
Select * from emp_1605 for update of salary; 
BEGIN
 OPEN mycur;
   LOOP
    fetch mycur into emp_rec1;         
    exit when mycur%notfound; 
    insert into emp_bac values(emp_rec1.ename,emp_rec1.emp_id,emp_rec1.salary);
      if(emp_rec1.years<2) then
            Update emp_1605 set salary=emp_rec1.salary where current of mycur;
      elsif(emp_rec1.years>2 and emp_rec1.years<5) then
            Update emp_1605 set salary=(emp_rec1.salary*1.2) where current of mycur;
      else 
            Update emp_1605 set salary=(emp_rec1.salary)*1.25 where current of mycur;
      end if;

    DBMS_OUTPUT.PUT_LINE(emp_rec1.emp_id || ' ' || emp_rec1.ename);  
   END LOOP;
close mycur;  
End abbcx1 ;

execute abbcx1;


drop table emp_1605;
create table emp_1605
( emp_id number(2),
salary number(5),
ename varchar2(20),
years number(2));

insert into emp_1605 values(1,1000,'resham',1);
insert into emp_1605 values(2,2000,'resham1',3);
insert into emp_1605 values(3,3000,'resham2',6);

select * from emp_1605;
select * from emp_bac;
drop table emp_bac;

create table emp_bac (ename varchar(20),
                      empid number(2),
                      salary number(5));
---------------------------------------------- 
q5)
Create or replace procedure abbcx(empid IN number ) 
is
exp number:=0;
namee varchar(10);
sall emp_1605.salary%type;
Begin
Select  years,ename ,salary into exp,namee,sall from emp_1605 where emp_id=empid ;
insert into emp_bac values(namee,empid,sall);
if(exp<2) then
            Update emp_1605 set salary=sall where emp_id=empid;
elsif(exp>2 and exp<5) then
            Update emp_1605 set salary=sall*1.2 where emp_id=empid;
else
            Update emp_1605 set salary=sall*1.25 where emp_id=empid;
end if;
End abbcx ;

select * from emp_1605;
select * from emp_bac;

execute abbcx(3);
-----------------------------------------------
q4)
create table emp_160
(emp_id number(2),
ename varchar2(20), 
salary number(5),
deptid number(2)
);
insert into emp_160 values (1,'resham',1000,11);
insert into emp_160 values (2,'shiavni',2000,12);
select * from emp_160;

Create or replace procedure proc_16056( empp IN number ) 
is
avvg number:=0;
nam emp_160.ename%type;
Status varchar(20);
sal emp_160.salary%type;
deptn emp_160.deptid%type;
Begin
Select avg(salary),deptid into 
avvg,deptn from emp_160 group by deptid;
Select salary,ename into sal,nam from emp_160 where emp_id=empp;
If(sal > avvg ) then
Status:='greater';
Elsif(sal =avvg) then
Status :='equal';
Else 
Status:='less';
end if;
Dbms_output.put_line(sal || nam || empp || status);
End proc_16056;

execute proc_16056(1);
---------------------------------------------------------
TRIGGERS:

CREATE TABLE Account_log_16056
(
deleteInfo VARCHAR(20),
LOGGING_DATE DATE
);

SELECT * FROM emp_16056;

CREATE OR REPLACE TRIGGER trigg_16056
AFTER delete on emp_16056
FOR EACH ROW
BEGIN
INSERT INTO Account_log_16056
values('After delete',sysdate);
END trigg_16056;

delete from emp_16056 where emp_id>2;
select * from Account_log_16056;

alter trigger trigg_16056 disable;

drop trigger trigg_16056;

---------------------------------------
old and new values of trigger:

create table orders_16056
( order_id number(5),
quantity number(4),
cost_per_item number(8,2),
create_date date,
created_by varchar2(10)
);

create table orders_audit_16056
( order_id number(5),
quantity number(4),
cost_per_item number(8,2),

created_by varchar2(10)
);

create or replace trigger order_before_insert16056
before insert
on orders_16056
for each row

declare
  v_username varchar2(10);
  
begin
  --find username of person performing insert
  select user into v_username
  from dual;
  
  --update create_date field of dual table to current system date
  :new.create_date := sysdate;
  
  --update created_by field to the username of person performing 
  :new.created_by := v_username;
END order_before_insert16056;

create or replace trigger after_delete16056
after insert
on orders_16056
for each row

declare 
v_username varchar2(10);
begin

--find username of perso performing the insert
select user into v_username
from dual;

--insert record into table
insert into orders_audit_16056
(
order_id,
quantity,
cost_per_item,
created_by)
values
(:new.order_id, :new.quantity, :new.cost_per_item, v_username);

end after_delete16056;

alter trigger after_delete16056 disable;

insert into orders_16056 values (1,2,20,'2-jun-2014','resham');
select * from orders_audit_16056;
----------------------------------------------------------
Raise_application_error

set serveroutput on;
create or replace procedure test_1605
(n_test IN number,
n_result OUT number)
as
begin
if n_test > 100 then
--dbms_output.put_line('Number too large');
raise_application_error(-20010, 'Number too large');
end if;
n_result := n_test;
dbms_output.put_line(n_result);
end test_1605;

variable resultn number;
execute test_1605(400, :resultn);
print resultn;

execute test_1605(10, :resultn);
print resultn;

select * from employees;
-----------------------------------------------------------------
--USING SQLERRM AND SQLCODE
declare
    ename employees.name%type;
    v_code number;
    v_erm varchar2(64);
begin
    select name into ename from employees where id=2;
    exception
      when others then
        v_code := sqlcode;
        v_erm := substr(sqlerrm,1,64);
        dbms_output.put_line('the error code is--' || v_code || '-'|| v_erm);
end;
---------------------------------------------------------
TRIGGER ASSIGNMENT

select * from employee;


create or replace trigger trg
before insert
on employee
for each row
declare
v_date varchar2(20);
begin
select to_char(to_date(sysdate,'dd-mm-yyyy'),'DY') INTO v_date from dual;

if v_date='SAT'or v_date='SUN' then
raise_application_error(-20010,'illegal activity');
end if;
end trg;

--insert into employee values(125,'res','jj','trai',30909,'graeter','25-jun-17');
--------------------------------------------------------
ALTER TRIGGER TRG DISABLE;

create table old_order_history_16056 (ORDER_ID number(5),QTY_O number(4), COST_O number(5));
 
  create table norder_history_16056 (ORDER_ID number(5),QTY_O number(4), COST_O number(5));
 
 insert into norder_history_16056 values(101,5,50);
 insert into norder_history_16056 values(102,3,40);
 insert into norder_history_16056 values(103,8,30);
 
 create or replace trigger history_trigger_16056
 before update 
  on norder_history_16056
  for each row
  
  declare 
    h_qty number(4);
    h_cost number(5);
  
  begin 
   insert into old_order_history_16056 values(:old.ORDER_ID,:old.QTY_O,:old.COST_O);
    
  end history_trigger_16056;
  
 
 update norder_history_16056 set cost_o=45 where order_id =101; 
 select * from old_order_history_16056;
  select * from norder_history_16056;

----------------------------------------------
q) create procedure to display product details and custmer details for entered id.

create or replace procedure
  prod_details_16056(p_idd IN number,mobile out number, cust_name out varchar2,email out  varchar2,address out varchar2) 
  IS
  
  BEGIN
    select c.cust_name,c.email,c.mobile,c.address into cust_name,email,mobile,address
    from customer_16056 c,product_order_16056 
    where c.cust_id=product_order_16056.cust_id and product_order_16056.p_id=p_idd;
    EXCEPTION
      when others then
      raise_application_error(-20010,'the id not present');
      end prod_details_16056;
  
     variable pid number;
    variable custname varchar2(20);
variable em varchar2(40);
   variable mob number;
   variable addr varchar2(50);

            execute prod_details_16056(2,:mob,:custname,:em,:addr); 
            print pid;
print custname;
print em;
print mob;
print addr;
------------------------------------------------
q) create procedure that will accept p_id and increase its price by 10%


Create or replace procedure price_16056(p_idd IN number ) 
is
pricee product_16056.price%type;
Begin
Select price into pricee from product_16056 where p_id=p_idd ;
Update product_16056 set price=pricee*1.1 where p_id=p_idd;
End price_16056 ;

execute price_16056(4);
select * from product_16056;
------------------------------------------------
q)create procedure which will accept values for product table and insert it as a new row.

create or replace procedure insertProduct_16056(pid IN number,pdes IN varchar2,pricee IN number)
is
begin

insert into product_16056 values(pid,pdes,pricee);
commit;
end insertProduct_16056;



execute insertProduct_16056(6,'ppp',900);
----------------------------------------------


SET SERVEROUTPUT ON;

DECLARE
cursor mycur is select * from EMP where DEPTID=901;
BEGIN
	for emp_rec in mycur
	LOOP
	DBMS_OUTPUT.PUT_LINE(emp_rec.empid || ' ' || emp_rec.empname);
	END LOOP;
END;

--------------------------------------

DECLARE
    TYPE mytype IS REF CURSOR;     
    mycur mytype;                   
    emp_rec emp%rowtype;
    dept_rec department%rowtype;
BEGIN
 OPEN mycur for select * from emp where deptid=901;
   LOOP
    fetch mycur into emp_rec;         
    exit when mycur%notfound;       
    DBMS_OUTPUT.PUT_LINE(emp_rec.empid || ' ' || emp_rec.empname);  
   END LOOP;
  close mycur;  

  OPEN mycur for select * from department;
   LOOP
    fetch mycur into dept_rec;         
    exit when mycur%notfound;       
    DBMS_OUTPUT.PUT_LINE(dept_rec.dept_id || ' ' || dept_rec.dept_name);  
   END LOOP;
   close mycur;
END;

  
--------------------------------------------
   
  create table audittemp(num varchar(20));
  
  create or replace procedure
  get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number) IS
  BEGIN
    select empname,deptid into s_name,s_sal
    from emp
    where empid=s_code;
    EXCEPTION
      when no_data_found then
      insert into audittemp
      values('No employee with id' || s_code);
      s_name := null;
      s_sal := null;
      end get_details_16056;
   
   
  
      variable name1 varchar2(20);
      variable did number;
   
      execute get_details_16056(104, :name1, :did);
      print name1;
      print did;
--------------------------------------------
create or replace function crt_dept_16056(dno number,
   dname varchar2) RETURN   NUMBER 
   AS
   BEGIN 
    INSERT into department 
    values(dno,dname);
    return 1;
  EXCEPTION
    WHEN others THEN
    return 0;
    END crt_dept_16056;
    
    variable flag number;
    EXECUTE :flag:=crt_dept_16056(12,'production');
    print flag;
-----------------------------------------
create or replace package pckg_16056 AS
   procedure get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number);
   function crt_dept_16056 (dno number,
          dname varchar2) RETURN   NUMBER;
END pckg_16056;



create or replace package body pckg_16056 
    AS
      procedure get_details_16056(s_code IN number, s_name OUT varchar2, s_sal OUT number) IS
        BEGIN
          select empname,deptid into s_name,s_sal
          from emp
          where empid=s_code;
            EXCEPTION
              when no_data_found then
              insert into audittemp
              values('No employee with id' || s_code);
              s_name := null;
              s_sal := null;
      end get_details_16056;
      
      function crt_dept_16056(dno number,
          dname varchar2) RETURN   NUMBER 
          AS
             BEGIN 
              INSERT into department 
              values(dno,dname);
              return 1;
                  EXCEPTION
                    WHEN others THEN
                    return 0;
     END crt_dept_16056;
end pckg_16056;


variable name1 varchar2(20);
variable did number;
execute pckg_16056.get_details_16056(104, :name1, :did);
      print name1;
      print did;

variable flag number;
    EXECUTE :flag:=pckg_16056.crt_dept_16056(66,'prodn');
    print flag;
--------------------------------------------------------------
q1) return the cost of company using function
create table emp_16056 (emp_id number(2)not null,salary number(4),years number(2),primary key(emp_id));
insert into emp_16056 values (1,1000,1);
insert into emp_16056 values (2,2000,2);
insert into emp_16056 values (3,3000,3);
insert into emp_16056 values (4,4000,4);
insert into emp_16056 values (5,5000,5);
insert into emp_16056 values (6,1000,5);
update emp_16056 set years=1 where emp_id=3;
create or replace function sal_16056(emp_num number) RETURN   NUMBER 
   AS
   da number(5,2):= 0.15;
   hra number(5,2):= 0.20;
   ta number(5,2):=0.08;
   sa number(5,2);
   sall emp_16056.salary%TYPE := 0.00;
   yr emp_16056.years%TYPE;
   BEGIN
    select salary,years into sall,yr 
    from emp_16056 
    where emp_id=emp_num;
   if yr < 1
   then sa :=0;
   
   elsif yr >= 1 and  yr < 2 then
   sa := 0.1 * sall;
   
   elsif yr >= 2 and yr < 4 then
   sa := 0.2 * sall;
   
   elsif yr >= 4 then
   sa := 0.30 * sall;
   
   end if;
   sall := sall + sa + da * sall + hra * sall + ta * sall;
  return sall; 
   EXCEPTION 
       when no_data_found then
       return 0;
end sal_16056;
  
  variable flag number;
    EXECUTE :flag:=sal_16056(6);
    print flag;
--------------------------------------------------
TRIGGERS:

CREATE TABLE Account_log_16056
(
deleteInfo VARCHAR(20),
LOGGING_DATE DATE
);

SELECT * FROM emp_16056;

CREATE OR REPLACE TRIGGER trigg_16056
AFTER delete on emp_16056
FOR EACH ROW
BEGIN
INSERT INTO Account_log_16056
values('After delete',sysdate);
END trigg_16056;

delete from emp_16056 where emp_id>2;
select * from Account_log_16056;

alter trigger trigg_16056 disable;

drop trigger trigg_16056;

---------------------------------------
old and new values of trigger:

create table orders_16056
( order_id number(5),
quantity number(4),
cost_per_item number(8,2),
create_date date,
created_by varchar2(10)
);

create table orders_audit_16056
( order_id number(5),
quantity number(4),
cost_per_item number(8,2),

created_by varchar2(10)
);

create or replace trigger order_before_insert16056
before insert
on orders_16056
for each row

declare
  v_username varchar2(10);
  
begin
  --find username of person performing insert
  select user into v_username
  from dual;
  
  --update create_date field of dual table to current system date
  :new.create_date := sysdate;
  
  --update created_by field to the username of person performing 
  :new.created_by := v_username;
END order_before_insert16056;

create or replace trigger after_delete16056
after insert
on orders_16056
for each row

declare 
v_username varchar2(10);
begin

--find username of perso performing the insert
select user into v_username
from dual;

--insert record into table
insert into orders_audit_16056
(
order_id,
quantity,
cost_per_item,
created_by)
values
(:new.order_id, :new.quantity, :new.cost_per_item, v_username);

end after_delete16056;

alter trigger after_delete16056 disable;

insert into orders_16056 values (1,2,20,'2-jun-2014','resham');
select * from orders_audit_16056;
----------------------------------------------------------










create table product_16056 (p_id number(4),p_des varchar2(15),price number(9,2), primary key(p_id));

create table customer_16056 (cust_id number(4), cust_name varchar2(20),email varchar2(40),mobile number(10),address varchar2(50),primary key(cust_id));

create table product_order_16056(order_num number(4),p_id number(4),cust_id number(4),quantity number(3),order_date date ,primary key(order_num));

insert into product_16056 values (1,'cosmetics',200);
insert into product_16056 values (2,'groceries',300);
insert into product_16056 values (3,'drinks',100);
insert into product_16056 values (4,'cosmetics',1000);

insert into customer_16056 values(11,'abc','abc@gmail.com',1234567819,'pune');
insert into customer_16056 values(12,'xyz','xyz@gmail.com',1234564493,'akola');
insert into customer_16056 values(13,'pqr','pqr@gmail.com',1234987097,'pune');
insert into customer_16056 values(14,'qqq','qqq@gmail.com',1111226789,'mumbai');

insert into product_order_16056 values (1,1,11,2,'17-may-2017');
insert into product_order_16056 values (2,2,12,1,'18-april-2016');
insert into product_order_16056 values (3,3,13,3,'22-jan-2017');
insert into product_order_16056 values (4,4,14,1,'20-feb-2017');






 set serveroutput on;




select c.cust_name,c.email,c.mobile,c.address 
    from customer_16056 c,product_order_16056 
    where c.cust_id=product_order_16056.cust_id and product_order_16056.p_id=1;
















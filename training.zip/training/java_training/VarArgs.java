public class VarArgs
{

//function for printing numbers
public static void print(int a, int y, String...s)
{
System.out.println(a + " , " + y);

for(int i=0;i<s.length;i++)
{
System.out.println(s[i] + "\t");
}

System.out.println();
}

public static void main(String args[])
{
print(3,4);
print(1,2,"a","b");
System.out.println("next invoke");
print(5,6,"c","d","e");
//print(4); this will give error as mininum 2 arguments are required

}
}
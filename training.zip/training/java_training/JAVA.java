class HelloWorld
{
	
public static void main(String args[])
{
/*int count=0;
System.out.println("hello world");
for(int i=0;i<args.length;i++)  //addition of numbers
{
count=count+Integer.parseInt(args[i]);
}
System.out.println("addition= " +count);
set PATH=C:\Users\XBBNLJ4\Desktop\jdk1.6.0_25\bin or
C:\Program Files\Java\jdk1.8.0_92*/


}
}
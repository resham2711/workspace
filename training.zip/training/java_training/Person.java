import java.util.*;
public class Person // class Person {} --> class accessible only inside package if public not written
{
	//instance variables
	 int pid;
	 public String pname;
	 String pmobile;
	 Date dob;
	 float height;
	
	
	public Person()  //default constructor
	{
		pid=0;
		pname="";
		pmobile="";
		dob=null;
		height=0.0f;
		
	//this(0,"","",null,0.0f);  //call the constructor of same class. same functionality as above assignments

	}
	public Person(int id,String name,String mob,Date d,float h)
	{
		pid=id;
		pname=name;
		pmobile=mob;
		dob=d;
		height=h;
	}
	/*public static void main(String args[])
	{
		Person p[]=new Person[2];
		PersonService ps= new PersonService();
		ps.acceptPersons(p);
		ps.displayPersons(p);
	}
	/*public String toString()
	{
		return("id : " + pid + "name :" + pname + "mobile : " + pmobile + " date of birth : " + dob + "height : " + height );
	}
	
	public void display()
	{
		System.out.println("person id : " + pid);
		System.out.println("person name: " + pname);
        System.out.println("person mobile number : " + pmobile);
		System.out.println("person date of birth : " + dob);
		System.out.println("person height : " + height);
	}	*/
}
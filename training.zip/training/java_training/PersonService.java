import java.util.*;
public class PersonService
{
	
	public static void acceptPersons(Person[] p)
	{
		Scanner sc=new Scanner(System.in);
	
		for(int i=0;i<p.length;i++)
		{
			
			System.out.println("enter the name of " + i + "person : ");
			p[i].pname=sc.next();
			System.out.println("enter the id of " + i + "person : ");
			p[i].pid=sc.nextInt();
			
			

		}
		
	}
	
	public static  void displayPersons(Person[] p)
	{
		for(int i=0;i<p.length;i++)
		{
			System.out.println("name of person is : " +p[i].pname);
			System.out.println("id of person is : " +p[i].pid);
		}
	}
}
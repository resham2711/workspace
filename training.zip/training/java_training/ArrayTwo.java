import java.util.*;
public class ArrayTwo
{
public static void main(String args[])
{
	int arr[][]=new int[2][3];
	//ArrayService as= new ArrayService();
	/*as.acceptElements(arr);  //in ArrayService class, no values are present. so creating empty objects is of no sense. thus instead make the methods in 
							    ArrayService class as static;
	as.dispalyElements(arr);*/
	
	ArrayService.acceptElements(arr);
	ArrayService.displayElements(arr);
	
	/*  code rewritten in function in ArrayService.java
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the array elements:");
	for(int i=0;i<arr.length;i++)
	{
		for(int j=0;j<arr[0].length;j++)
		{
		System.out.println("enter the " +  i + "," + j + " value:");
		arr[i][j]=sc.nextInt();
		}
	}
	
	System.out.println("the array is : ");
	for(int i=0;i<arr.length;i++)
	{   System.out.println();
		for(int j=0;j<arr[0].length;j++)
		{
			System.out.print(arr[i][j]);
			System.out.print("\t");
		}
		System.out.println();
	}*/
}
}
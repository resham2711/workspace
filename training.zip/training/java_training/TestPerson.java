import java.util.*;
class TestPerson
{
public static void main(String args[])
{	/*Person p1=new Person();
	p1.display();*/
	
	Person p=new Person(1,"resham","12345",new Date(),1.2f);
	System.out.println(p);
	//p.display();
	/*System.out.println(p); wil give address as "object class" will provide toString() .
	to avoid this,we need to write toString() in "person class" to display values of "p" using sout.*/
}
}
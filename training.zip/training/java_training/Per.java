public class Per
{
public static void main(String args[])
	{
		Person p[]=new Person[2];
		for(int i=0;i<p.length;i++)
		{
			p[i]=new Person();
		}
		//PersonService ps= new PersonService();
		PersonService.acceptPersons(p);
		PersonService.displayPersons(p);
	}
}
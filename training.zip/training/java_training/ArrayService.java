import java.util.*;
public class ArrayService
{
	public static void acceptElements(int [][] arr)
	{
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the array elements:");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[0].length;j++)
			{
				System.out.println("enter the " +  i + "," + j + " value:");
				arr[i][j]=sc.nextInt();
			}
		}
	}
	public static void displayElements(int[][] a)
	{
		System.out.println("the array is : ");
			for(int i=0;i<a.length;i++)
			{   
				System.out.println();
				for(int j=0;j<a[0].length;j++)
				{
					System.out.print(a[i][j]);
					System.out.print("\t");
				}
				System.out.println();	
	
			}
	}	
}
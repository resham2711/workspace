package com.demo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.model.NonPerishableProduct;
import com.demo.model.PerishableProduct;
import com.demo.model.Product;

import oracle.jdbc.internal.OracleTypes;
import oracle.jdbc.oracore.OracleType;

public class DBProductOp {

	/*
	 * This method is actually adding the product details into the database
	 */
	public static void addDB(Product p)
	{
		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_add_j0(?,?,?,?,?,?)}");
			pst.setString(1, p.getProd_id());
			pst.setString(2, p.getProd_name());
			pst.setInt(3, p.getQuantity());
			pst.setDouble(4, p.getPrice());
			
			
			if(p instanceof PerishableProduct)
			{
				PerishableProduct pi=(PerishableProduct) p;
				pst.setString(5, pi.getType());
				pst.setString(6,pi.getExpdate());
			}
			else
			{
				NonPerishableProduct pi=(NonPerishableProduct) p;
				pst.setString(5, pi.getType());
				pst.setString(6,pi.getCategory());
			}
			if(pst.executeUpdate()>0)
				System.out.println("\n\t### Product Added..!!!");
			else
				System.out.println("\n\t### Matter ho gaya..");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * This method is actually deleting the product details from the database
	 */
	public static void deleteDB(String id) {

		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_del_j0(?,?)}");
			pst.setString(1, id);
			pst.registerOutParameter(2, java.sql.Types.INTEGER);
			pst.executeUpdate();
			pst.getInt(2);
			System.out.println("\n\t### Product Deleted..!!!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * This method is  searching the product details from the database
	 */
	public static int searchProduct(String id) {

		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_search_j0(?,?)}");
			pst.setString(1, id);
			pst.registerOutParameter(2,  OracleTypes.CURSOR);
			pst.execute();
			ResultSet r=(ResultSet) pst.getObject(2);
			if(r.next())
			{	
				System.out.println("\n\t Name\t:"+r.getString(2));
				System.out.println("\n\t Quantity\t:"+r.getString(3));
				System.out.println("\n\t Price\t:"+r.getString(4));
				System.out.println("\n\t Type\t:"+r.getString(5));
				System.out.println("\n\t ExpDate/Category\t:"+r.getString(6));
				
				return 1;
			}
			else
			{
				System.out.println("\n\t### Product Not Found..!!!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
		
	}

	/*
	 * This method is actually updating the product details into the database
	 */
	public static void updateDB(String id,String name,int qty) {
		
		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_update_j0(?,?,?)}");
			pst.setString(1, id);
			pst.setString(2, name);
			pst.setInt(3, qty);
			pst.executeUpdate();
			System.out.println("\n\t### Product Updated..!!!");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * This method is actually displaying the product details from the database
	 */
	public static void searchAll() {

		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_searchall_j0(?)}");
			pst.registerOutParameter(1,  OracleTypes.CURSOR);
			pst.execute();
			ResultSet r=(ResultSet) pst.getObject(1);
			System.out.println("\n\tID\tName\t\tQuantity\tPrice\tType\tExpDate/Category\n");
			while(r.next())
			{	
				System.out.println("\t"+r.getString(1)+"\t"+r.getString(2)+"\t\t\t"+r.getInt(3)+"\t"+r.getInt(4)+"\t"
			+r.getString(5)+"\t"+r.getString(6));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * This method is actually displaying the product history from the database
	 */
	public static void history() {
		Connection conn=DBUtil.getMyConnection();
		try {
			CallableStatement pst=conn.prepareCall("{call prod_histAll_j0(?)}");
			pst.registerOutParameter(1,  OracleTypes.CURSOR);
			pst.execute();
			ResultSet r=(ResultSet) pst.getObject(1);
			System.out.println("\n\tID\tName\t\tQuantity\tPrice\tType\tExpDate/Category\n");
			while(r.next())
			{	
				System.out.println("\t"+r.getString(1)+"\t"+r.getString(2)+"\t\t\t"+r.getInt(3)+"\t"+r.getInt(4)+"\t"
			+r.getString(5)+"\t"+r.getString(6));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}

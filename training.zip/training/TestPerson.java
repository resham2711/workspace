import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPerson {

	Person per;

	@Before
	public void setUp() throws Exception {
		System.out.println("Setup called");
		per = new Person("Robert", "King");

	}

	@After
	public void tearDown() throws Exception {
		System.out.println("tearDown");
	}

	@Test
	public void testGetFullName() {
		System.out.println("from testPerson1");
		assertEquals("Robert King", per.getFullName());

	}
	@Test
	public void checkNullsInName() {
		System.out.println("from testPerson1");
		assertEquals("full name null", per.getFullName());
		assertEquals("first name null", per.getFirstname());

	}
	@Test
	public void testFirstName() {
		System.out.println("from testPerson1");
		assertEquals("Robert", per.getFirstname());

	}
	@Test
	public void testLastName() {
		System.out.println("from testPerson1");
		assertEquals("King", per.getLastname());

	}
}


public @interface Anno2 {
String value();  
String name() default"shiv"; //by default,shiv aaenga name mai
//String[] str();
}

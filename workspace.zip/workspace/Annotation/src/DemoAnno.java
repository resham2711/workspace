@Anno2(
		value="111")


public class DemoAnno {

	
	@Anno
	public static void display()
	{
		System.out.println("hello....");
	
	
	}
	public static void main(String [] args){
		display();
	}
}

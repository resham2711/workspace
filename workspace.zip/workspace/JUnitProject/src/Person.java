
public class Person {
private String firstname;
private String lastname;
public Person(String fname,String lname)
{
	if(fname==null && lname==null)
	{	throw new IllegalArgumentException("both names cannot be empty");
}
	this.firstname=fname;
	this.lastname=lname;
}
public String getFullName()
{
	String first=(this.firstname!=null)? this.firstname:"?";
	String last=(this.lastname!=null)? this.lastname:"?";
return first + " " + last;
}
public String getFirstname() {
	return this.firstname;
}


public String getLastname() {
	return this.lastname;
}

public static void main(String args[])
{
	Person p=new Person("a","b");
	System.out.println(p.getFirstname());
}

}

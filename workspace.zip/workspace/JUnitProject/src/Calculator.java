import org.junit.runners.Parameterized;

public class Calculator
{
public static int squared(int x)
{
	return x*x;
}

public static int cube(int x)
{
	return x*x*x;
}
}



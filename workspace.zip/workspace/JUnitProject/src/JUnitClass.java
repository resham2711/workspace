import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitClass {

	@Test
	public void TestSquare()
	{
		assertEquals(Calculator.squared(4),16);
	}
	@Test
	public void TestCube()
	{
		assertEquals(Calculator.cube(2),8);
	}

}

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPerson {

	Person per;
	@Before
	public void setUp()
	{
		System.out.println("setup called");
		per=new Person("robert","king");
	}
	
	@Test
	public void NullsInName()
	{
		System.out.println("from TestPerson1");
		assertNotNull("full name null",per.getFullName());
		assertNotNull("first name null",per.getFirstname());
		assertEquals(per.getFirstname(), "robert");
	}
	
	@Test
	public void testGetLastName()
	{
		assertEquals(per.getLastname(),"king");
	}
@After
public void tearDown()
{
	System.out.println("teardown called");
}
}

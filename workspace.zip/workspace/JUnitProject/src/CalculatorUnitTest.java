import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import junit.framework.Assert;

@RunWith(Parameterized.class)
public class CalculatorUnitTest {
@Parameterized.Parameters
public static Collection data()
{
	return Arrays.asList(new Object[][]{{0,0},{1,1},{2,4},{3,9}});
	
}
private int input;
private int expected;
public CalculatorUnitTest(int input, int expected) {
	super();
	this.input = input;
	this.expected = expected;
}
@Test
public void test()
{
	System.out.println("running parameterized tests");
	Assert.assertEquals(expected,Calculator.squared(input));
}
}

package com.demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CurrencyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext ctx=new ClassPathXmlApplicationContext("currency.xml");
CurrencyConverterInterface c=(CurrencyConverter)ctx.getBean("currency");
System.out.println(c.dollarsToRupee(20));

	}

}

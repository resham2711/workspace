package com.demo.bean;

public interface ExchangeServiceInterface {
public double getExchangeRate();
}

package com.demo.bean;
import org.springframework.stereotype.Component;

@Component
public class ExchangeService implements ExchangeServiceInterface {

	public double getExchangeRate() {
		// TODO Auto-generated method stub
		return 63.22;
	}

}

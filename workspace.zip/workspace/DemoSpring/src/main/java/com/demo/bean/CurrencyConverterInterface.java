package com.demo.bean;

public interface CurrencyConverterInterface {
	public double dollarsToRupee(double dollars);
}

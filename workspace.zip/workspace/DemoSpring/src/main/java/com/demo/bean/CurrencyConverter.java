package com.demo.bean;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component("currency")
public class CurrencyConverter implements CurrencyConverterInterface,BeanNameAware,BeanFactoryAware,ApplicationContextAware,DisposableBean{
	@Autowired
	private ExchangeService exchangeService;
	
	
	
	public ExchangeService getExchangeService() {
		return exchangeService;
	}


@Required  //this value cannot be null
@Autowired
	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}



@PostConstruct
public void myInit()
{
	System.out.println("in init.....");
}

public double dollarsToRupee(double dollars)
{
	return dollars*exchangeService.getExchangeRate();
}

@PreDestroy
public void myDestroy()
{
	System.out.println("in destroy...");
}


public void setBeanName(String arg0) {
	// TODO Auto-generated method stub
	System.out.println("set bean name....");
}


public void setBeanFactory(BeanFactory arg0) throws BeansException {
	// TODO Auto-generated method stub
	System.out.println("set bean factory...");
	
}


public void setApplicationContext(ApplicationContext arg0) throws BeansException {
	// TODO Auto-generated method stub
	System.out.println("app....");
	
}


public void destroy() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("destroy.....");
	
}

}

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<String> ob = new ArrayList<>(); // generics: passing the
													// data-type.
		ob.add("resham");
		ob.add("8");
		//System.out.println(ob);

		HashSet<Integer> al = new HashSet<>();
		al.add(3);
		al.add(1);
		al.add(9);
		// a1.add(1);
		//System.out.println("hashset: " + al);
		
		TreeSet<Integer> ts = new TreeSet<>();
		ts.add(44);
		ts.add(54);
		//System.out.println("treeset: " + ts);

		TreeSet<Person> pr = new TreeSet<>();
		pr.add(new Person("resham", "111", new Date(), 2.2f, "aaa"));
		
		if(pr.add(new Person("resh", "11", new Date(), 2.2f, "aa"))==false)
				{
			System.out.println("duplicate values");
				}
		
		pr.add(new Person("shivani", "1111", new Date(), 2.1f, "pp"));
		//System.out.println("person: " + pr +"\n");
		
		
		TreeSet<Person> pr1 = new TreeSet<>(new NameComparator()); //organize data on name.
		pr1.add(new Person("resham", "111", new Date(), 2.2f, "aaa"));
		pr1.add(new Person("resh", "111", new Date(), 2.2f, "aaa"));
		//System.out.println(pr1);
	
	for(Person p:pr1)  //object becomes read only
	{
		//p.display();
		if(p.getHeight()>5.0f){
			p.display();
			System.out.println();
			//System.out.println(p);
		}
	}
	
	Iterator  itr=pr1.iterator();
	while(itr.hasNext()){
		Person o=(Person)itr.next();
		o.display();
	}
	ArrayList<Integer> all = new ArrayList<>();
		all.addAll(al);
		//System.out.println("arraylist: " + all);
	}

}

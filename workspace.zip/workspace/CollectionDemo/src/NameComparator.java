import java.util.Comparator;

public class NameComparator implements Comparator<Person> //by specifying <person> type,now u can directly write Person type object in methods instead of using object type objects and then typecasting them.
{
public int compare(Person o1,Person o2)
{
	return o1.getName().compareTo(o2.getName()); //compare the names of objects.
	
}
}

import java.util.*;

import com.sun.xml.internal.bind.v2.runtime.output.StAXExStreamWriterOutput;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, Person> hm = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 2; i++) {
			System.out.println(" enter name: ");
			String name = sc.next();
			System.out.println(" enter mobile number: ");
			String mob = sc.next();
			System.out.println("enter height: ");
			float height = sc.nextFloat();
			System.out.println("enter email: ");
			String em = sc.next();
			Person p = new Person(name, mob, new Date(), height, em);
			hm.put(p.getId(), p);
		}
		System.out.println("enter id for search: ");
		int id = sc.nextInt();
		Person p1 = hm.get(id);// retrieve value against the given id. will give
								// a person object.
		p1.display();
		
		Set<Integer> s = hm.keySet();  //keys hai in set of type integer
		for (int key : s) {
			Person p2 = hm.get(key);
			System.out.println(" set..." + p2);

		}
		Iterator itr1 = s.iterator();
		while (itr1.hasNext()) {
			int k = (Integer) itr1.next();
			Person p3=hm.get(k); //getting values of person of id=key.
			System.out.println("iii..." + p3);
			//System.out.println(p1);
		}
	}

}

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationService {
	ObjectInputStream ois = null;
	ObjectOutputStream oos = null;

	public SerializationService(String fname) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(fname));  
			ois = new ObjectInputStream(new FileInputStream(fname));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void writeFile(Person [] parr)
	{
		//writing person objects stored in array into file. thus using ObjectOutputStream.
		for(Person p:parr)
		{
			try {
				oos.writeObject(p);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void readFile()
	{ //reading the object and displaying it.
		while(true){
		try {
			Person p=(Person)ois.readObject();
			if(p==null)
			{break;}
			System.out.println(p);
		} catch(EOFException e)
		{
			System.out.println("reached end of file...");
			break;
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
	public void closeFiles()
	{
		try {
			oos.close();
			ois.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

import java.io.DataInputStream;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class CopyFile {
	static FileInputStream fis = null; // as copyfile mai access karna hai.//
										// islea global declare kiye.
	static DataInputStream dis = null;
	static DataOutputStream dos = null;

	static FileOutputStream fos = null;
	static int i ;

	public static void openFile(String inf, String outf) {
		try {
			fis = new FileInputStream(outf); //as we are reading and writing from same file
			dis = new DataInputStream(fis); // chaining

			fos = new FileOutputStream(outf);
			dos = new DataOutputStream(fos);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void copyFile() {
		try {
			int i = fis.read();
			while (i != -1) {
				fos.write(i);
				i = fis.read();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void closeFile() {
		try {
			fis.close();
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void writeData() {
		// use dataoutstream to write
		Scanner sc = new Scanner(System.in);

		try {
			System.out.println(" enter int: ");
			i = sc.nextInt();
			dos.writeInt(i);

			System.out.println(" enter double: ");
			double b = sc.nextDouble();
			dos.writeDouble(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void readData()
	{
		try {
			int j=dis.readInt();
			double d=dis.readDouble();
			System.out.println("int is : " + j);
			System.out.println("double is : " + d);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}

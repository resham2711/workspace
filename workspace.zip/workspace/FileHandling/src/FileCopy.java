import java.io.File;

public class FileCopy {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
CopyFile.openFile(args[0],args[1]);
//CopyFile.copyFile();
CopyFile.writeData();
CopyFile.readData();
CopyFile.closeFile();
/*File f=new File("abc.txt");
boolean ans=f.exists();
if(ans)
{

}*/

	}

}

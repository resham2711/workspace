import java.util.Date;

public class SerializableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person[] parr = { new Person("resham", "111", new Date(), 2.2f, "ttt"),
				new Person("resh", "1112", new Date(), 2.1f, "tt"),
				new Person("reshu", "11166", new Date(), 2.6f, "tttt") };
		SerializationService s = new SerializationService(args[0]);
		s.writeFile(parr); // functions
		s.readFile();
		s.closeFiles();
	}

}

import java.util.Scanner;

public class MyTable {

/*private static int num;
private static int n;
*/
public static void main(String args[]){
		
		
	TableTest t=new TableTest(3);  //kaunse number ka hona table t.createTable(3);
	TableTest tt=new TableTest(2);
	
	MyThread t1=new MyThread(t,10);  //kab tak table print hona
	t1.start();
	
	MyThread t2=new MyThread(tt,5); 
	
	t2.start();

	}
}

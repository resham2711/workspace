
public class TableTestSingle {

	public static void main(String[] args) {
		TableTest t=new TableTest(2);
		t.createTable(10);
     t.createTable(2);
	}

}

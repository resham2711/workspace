
public class TableTest {
	private int num;
	public TableTest(int num)
	{
		this.num=num;     //kab tak table hona
	}

	public synchronized void  createTable(int n)
//n is kaunse number ka hona
{
		System.out.println("table of " + num + " is : ");
		for(int i=1;i<=n;i++)
		{
			System.out.println( num + " * " + i + " = " + num*i);
		}
		}
}


public class MyThread extends Thread {
private TableTest t;  //jo hi constructor mai pass karna hai usko private karo.
private int x; //kaunse number ka print karana hai
public MyThread(TableTest t,int x)
{this.t=t;
this.x=x;
	}

public void run(){
	t.createTable(x);  //jo main mai tha wo idhar aaenga
}
}

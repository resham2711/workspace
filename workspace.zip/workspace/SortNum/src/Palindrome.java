import java.util.Arrays;
import java.util.Scanner;

public class Palindrome 
{
public static void main(String args[])
{
	System.out.println("enter string");
	Scanner sc= new Scanner(System.in);
	

	String original, reverse = "";
   
    original = sc.nextLine();

    int length = original.length();

    for ( int i = length - 1; i >= 0; i-- )
       reverse = reverse + original.charAt(i);

    if (original.equals(reverse))
       System.out.println("Entered string is a palindrome.");
    else
       System.out.println("Entered string is not a palindrome.");

	
	boolean f=true;
	if(original.length()<26)
	{
		System.out.println("not panagram");	
	}
	else{
	for(char p='a';p<='z';p++)
	{
		if(original.contains(""+p))
		{
			
			f=true;
		}
	}
	
	if(f==true){
		System.out.println("yes,it's panagram");
	}
	
}
}
}

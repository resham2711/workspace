import java.util.Scanner;

public class SortNum
{ 	static int n;
	static int i;
	static int j;
	static int k;
	static int p;
	static int count=0;
	static int temp;
public static void main(String args[])
{
	
	
	int temp;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter n");
	 n=sc.nextInt();
	
	int arr[]=new int[n];
	accept(n,arr);
	Display(arr,n);
	sort(arr,n);
	Display(arr,n);
	

	//Display(arr);
	
	System.out.println("enter element to search:");
	int el=sc.nextInt();
	int ans=search(el,arr,n);
	if(ans==0)
	{
		System.out.println("not present");
	}
	else if(ans==1)
	{
		System.out.println("present");	
	}
}
public static void accept(int n,int arr[])
{
	
	System.out.println("enter elements:");
	for( i=0;i<n;i++)
	{
		Scanner sc= new Scanner(System.in);
		arr[i]=sc.nextInt();
	}
	System.out.println("in");
	
	//return arr;
}

public static void sort(int arr[],int n)
{
	
	for( i=0;i<n;i++)
	{
		for( j=1;j<n-i;j++)
		{
			if(arr[j-1]>arr[j])
			{
				temp=arr[j-1];
				arr[j-1]=arr[j];
				arr[j]=temp;
			}
		}
	}
	System.out.println("sorted array:");
	
	//return arr;
}

public static void Display(int arr[],int n)
{
	System.out.println("in display");
	for(p=0;p<n;p++)
	{  //System.out.println("---");
		System.out.println(arr[p]);
	}
}

public static int search(int el,int arr[],int n)
{
	for(i=0;i<n;i++)
	{
		if(arr[i]==el)
		{
			count++;
		}
	}
	if(count==0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

}

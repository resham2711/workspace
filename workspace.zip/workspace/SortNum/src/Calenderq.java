import java.util.Scanner;

public class Calenderq 
{
public static void main(String args[])
{
	System.out.println("enter number of days in month:");
	Scanner sc= new Scanner(System.in);
	int n=sc.nextInt();
	System.out.println("enter the start day number for month:");
	int d=sc.nextInt();
	if((n==30||n==31||n==28||n==29) && d<7)
	{
		
		
		
	System.out.println("M\t"+"T\t" + "W\t" + "T\t" + "F\t" + "S\t" + "S\t");
	for(int i=2;i<=d;i++)
	{
		System.out.print(" \t");
	}
	int k=1;
	while(k<=n)
	{
		for(int i=1;i<=7;i++)
		{while(k<=n){
			for(int j=d;j<=7;j++)
			{ if(k<=n){
				System.out.print(k+" \t");
				k++;}
				
			}
			
			System.out.println();
			d=1;
		}
		}
	}
	}
	
	else
	{
		System.out.println("�rror");
	}
	
}
}


public interface Interface1 {

	void m1();
	int m2(String s);
}

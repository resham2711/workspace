
import java.util.*;
public class Person // class Person {} --> class accessible only inside package if public not written
{
	static{
		count=0;
	}
	//instance variables
	static int count;
	 int pid;
	 public String pname;
	 String pmobile;
	 Date dob;
	 float height;
	 String email;
	
	
	public Person()  //default constructor
	{
		
		/*pid=++count; //pid=0;
		pname="";
		pmobile="";
		dob=null;
		height=0.0f;
		System.out.println("person default");*/
		
	this("","",null,0.0f," ");  //call the constructor of same class. same functionality as above assignments

	}
	public Person(String name,String mob,Date d,float h,String em)
	{
		System.out.println("person param");
		pid=++count;
		pname=name;
		pmobile=mob;
		dob=d;
		height=h;
		email=em;
		
	}
	/*public static void main(String args[])
	{
		Person p[]=new Person[2];
		PersonService ps= new PersonService();
		ps.acceptPersons(p);
		ps.displayPersons(p);
	}*/
	
	public String toString()
	{
		return("id : " + pid + "name :" + pname + "mobile : " + pmobile + " date of birth : " + dob + "height : " + height + "email: " + email);
	}

	/*public static int getCount() {
		return count;
	}
	public static void setCount(int count) {
		Person.count = count;
	}*/
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void display()
	{
		System.out.println("person id : " + pid);
		System.out.println("person name: " + pname);
        System.out.println("person mobile number : " + pmobile);
		System.out.println("person date of birth : " + dob);
		System.out.println("person height : " + height);
		System.out.println();
	}	
	
	public void setId(int id)
	{
		pid=id;
	}
	public void setName(String name)
	{
		pname=name;
	}
	public void setMobile(String mobile)
	{
		pmobile=mobile;
	}
	
	public int getId()
	{
		return pid;
	}
	public String getName()
	{
		return pname;
	}
	public String getMobile()
	{
		return pmobile;
	}
	
}

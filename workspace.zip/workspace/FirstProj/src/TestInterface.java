
public class TestInterface 
{
 public static void main(String args[])
 {
	 MyClass m = new MyClass(); //can call all methods
	 m.m1();
	 m.method2();
	 m.m2("y");
	 m.m3(9);
	 m.m4();
	 
	 FirstInterface fi; //creating reference
	 
	 
	 FirstInterface i=new MyClass(); //can call all methods
	 i.method2();

	 Interface1 f=new MyClass();  //f is pointing to MyClass. only the methods in interface1 can be accessed.
	 
	 System.out.println(FirstInterface.j); //j defined in interface. can be accessed here.
	 
	 Interface2 f2=new MyClass(); //call methods only present in interface2
	 f2.m4();
	 
 }
}


public class MyClass implements FirstInterface
{

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("in m1");
		
	}

	@Override
	public int m2(String s) {
		// TODO Auto-generated method stub
		System.out.println("in m2");
		return 0;
	}

	@Override
	public void m3(int n) {
		System.out.println("in m3");
		// TODO Auto-generated method stub
		
	}

	@Override
	public String m4() {
		System.out.println("in m4");
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int method1(int i) {
		System.out.println("in method1");
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void method3() {
		System.out.println("in method3");
		// TODO Auto-generated method stub
		
	}
 
}

import java.util.*;

public class TestPerson
{
static{
	System.out.println("in static block");
	//Person ob;
}
	public static void main(String[] args)
	{
		System.out.println("in main");
		System.out.println();
		//ob=new Person("rr","111",new Date(),1.4f);
		//Person p=new Person("resham","123456",new Date(),12.9f);
		//p.display();
		
		/*Person pp=new Person();
		pp.setId(10);
		pp.setName("shiv");
		System.out.println(pp.getId());
		System.out.println(pp.getName());
		
		Person p1=new Person("resh","123456",new Date(),2.9f);
		p1.display();*/
		
		
		Person p[]=new Person[2];
		
		
		for(int i=0;i<p.length;i++)
		{
			p[i]=new Person();
		}
		
		try{
			PersonService.acceptPersons(p);
			System.out.println("in try"); //this wont be executed if u handling the exception of personservice here again.
			}catch(HeightException e)
			{
				System.out.println(e.getMessage());
			}
		
		PersonService.displayPersons(p);
		
		Scanner sc=new Scanner(System.in);
		System.out.println(" enter id to search: ");
		int idd =sc.nextInt();
		PersonService.searchId(p, idd); 
		
		System.out.println(" enter name to search: ");
		String name =sc.next();
		PersonService.searchName(p, name); 
	}

}

import java.util.*;
public class PersonService
{
	
	public static void acceptPersons(Person[] p) throws HeightException  //throws written if u remove try catch block
	{
		Scanner sc=new Scanner(System.in);
	
		for(int i=0;i<p.length;i++)
		{
			
			System.out.println("enter the name of " + i + " person : ");
			String pname=sc.next();
			//System.out.println("enter the id of " + i + " person : ");
			//p[i].pid=sc.nextInt();
			System.out.println("enter the mobile number of " + i + " person : ");
			String pmobile=sc.next();
			System.out.println("enter the height of " + i + " person : ");
			int height=sc.nextInt();
			try{
			if(height <1)
			{
				throw new HeightException("height should be > 1");  //anonymous object this is handled by catch here
			}
			p[i]=new Person(pname,pmobile,new Date(),height,null);
			}catch(HeightException e)
			{
				System.out.println(e.getMessage());
				
				throw e; //written if u want to handle the exception again in main()
			}
			
			
		}
		
	}
	
	public static  void displayPersons(Person[] p)
	{
		for(int i=0;i<p.length;i++)
		{
			System.out.println("name of person is : " +p[i].pname);
			System.out.println("id of person is : " +p[i].pid);
		}
	}
	
	public static void searchId(Person[]p,int id)
	{
		for(int i=0;i<p.length;i++)
		{
			if(p[i].getId()==id)
			{
				System.out.println("name: " + p[i].getName());
				System.out.println("mobile: " + p[i].getMobile());
			}
		}
	}
	
	public static void searchName(Person[]p,String name)
	{  int c=0;
		for(int i=0;i<p.length;i++)
		{
			if(p[i].getName().equals(name))
			{
				
				c++;
			}
			
		}
		if(c>0)
		{
		System.out.println("found");
		}
		else
		{
			System.out.println("not found");
		}
			
	}
	
}
import java.util.Date;

public class TestEmployee {

	public static void main(String[] args) 
	{
		//String name,String mob,Date da,float h,String d,String des,double sal
		//Employee e=new Employee("resham","1111",new Date(),9.8f,"rr","trainee","mgr",12334);//object cannot be created if emp is abstract
		//System.out.println(e);
		//System.out.println("salary of employee: " + e.calculateSalary());
		
		//function overridding---dynamic poly.
		Employee e1=new SalariedEmp("resham","1111",new Date(),9.8f,"rr","trainee","mgr",12334,2,4444);   //reference of employee pointing to object of salariedemp;
		System.out.println("hello : " + e1.calculateSalary()); //if calcsal() not present in emp,then compile error
		
		//String name,String mob,Date da,float h,String d,String des,double sal,int nl,double b
		//SalariedEmp se=new SalariedEmp("resham","1111",new Date(),9.8f,"rr","trainee","mgr",12334,2,4444);
		//System.out.println(se);
		//System.out.println("salary of salaried employee: " + se.calculateSalary()); 
		
		
		//another way of creating object by using setters and getters in any value.
		/*SalariedEmp se1=new SalariedEmp(); //call to default constructor
		se1.setName("ddd");
		
		//String name,String mob,Date da,float h,String d,String des,double sal,int hour
		ContractorEmp ce=new ContractorEmp("resham","1111",new Date(),2.2f,"rr","trainee","mgr",12345,20);
		//System.out.println(ce);
		System.out.println("salary of contractor employee: " + ce.calculateSalary());*/
	}

}

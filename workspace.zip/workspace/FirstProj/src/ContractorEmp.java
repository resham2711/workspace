import java.util.Date;

public class ContractorEmp extends Employee
{

	private int hour_wages;
	public ContractorEmp()
	{
		this("","",null,0.0f,"","","",0.0 ,0);
		System.out.println("in cntract deafult");
	}
	
	public ContractorEmp(String name,String mob,Date da,float h,String em,String d,String des,double sal,int hour)
	{
		 super(name,mob,da,h,em,d,des,sal);
		 hour_wages=hour;
		 System.out.println("in cntract param");
	}
	
	public int getHour_wages() {
		return hour_wages;
	}

	public void setHour_wages(int hour_wages) {
		this.hour_wages = hour_wages;
	}

	public String toString()
	{
		return super.toString() + " hour_wages: " + hour_wages;
	}
	
	public double calculateSalary()
	{
		return hour_wages*20;
	}
}


public interface FirstInterface extends Interface1,Interface2
{

	int method1(int i);
	int j=1;
	default int method2()
	{
		System.out.println("in default method");
		return 1;
	}
	void method3();
	
}

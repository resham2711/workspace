
public class HeightException extends Exception
{
public HeightException(String msg)
{
	super(msg);
}
}

import java.util.Date;

public class SalariedEmp extends Employee 
{
 private int numOfLeave;
 private double bonus;
 
 public SalariedEmp()
 { 
	 this("","",null,0.0f,"","","",0.0 ,0 , 0.0);
	 System.out.println("Salaried emp default");
 }
 
 public SalariedEmp(String name,String mob,Date da,float h,String em,String d,String des,double sal,int nl,double b)
 {
	 super(name,mob,da,h,em,d,des,sal);
	 System.out.println("Salaried emp param");
	 numOfLeave=nl;
	 bonus=b;
 }
 
 public String toString()
 {
	 return super.toString() + "numer of leaves: " + numOfLeave + " bonus: " + bonus;
 }
 
public double calculateSalary()
 { System.out.println("in salaried");
	 double ss=getSal();  //salariedemp extends emp. emp has salary,getsal(). thus,Salariedemp can access the public method getSal(). 
	 ss=ss+bonus;
	
	 return ss;
 }

public int getNumOfLeave() {
	return numOfLeave;
}

public void setNumOfLeave(int numOfLeave) {
	this.numOfLeave = numOfLeave;
}

public double getBonus() {
	return bonus;
}

public void setBonus(double bonus) {
	this.bonus = bonus;
}
 
}

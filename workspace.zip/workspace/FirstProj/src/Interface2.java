
public interface Interface2 {

	void m3(int n);
	String m4();
}

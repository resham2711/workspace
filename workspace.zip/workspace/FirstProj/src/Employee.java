import java.util.Date;

public class Employee extends Person {

	private String dept,desg;
	private double salary;
	
	public Employee()
	{
		
		this("","",null,0.0f,"","","",0.0);
		
		/*pname=" ";
		pmobile=" ";
		dob=null;
		height=0.0f;
		dept=" ";
		desg=" ";
		salary=0.0;*/
		System.out.println("employee default");
	}
	public Employee(String name,String mob,Date da,float h,String em,String d,String des,double sal)
	
	{ super(name,mob,da,h,em);
		System.out.println("employee param");
		dept=d;
		desg=des;
		salary=sal;
	}
	
	public double calculateSalary()
	{
		System.out.println("in employee");
		return 0.0;
	}
	public void setDept(String id)
	{
		dept=id;
	}
	
	public String getDept()
	{
		return dept;
	}
	public void setSal(double sa)
	{
		salary=sa;
	}
	
	public double getSal()
	{
		return salary;
	}
	
	public String toString()
	{
		
		return super.toString()+ "department: " + dept + "designation: " + desg + "salary : " + salary;   //concatinating person toString with employees.
	}
}

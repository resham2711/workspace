function myfunction1()
{
	var s=document.getElementById("pwd").value;
//	var v=s.value;
	var s2=document.getElementById("cpwd").value;
	//alert(s);
	//alert(s2);
	//var v2=s2.value;
	if(s==s2)
		{
		  //alert("ïf");
		return true;
		}
	else{
		//alert("else");
		var id=document.getElementById("text2");
		id.style.color="red";
		id.style.fontSize="small";
		id.innerHTML="*password mismatch";
		return false;
		
		
	}

}

function myfunction2()
{
	var s=document.getElementById("nnpd").value;
//	var v=s.value;
	var s2=document.getElementById("ccpd").value;
	
	if(s==s2)
		{
		return true;
		}
	else
		{
		var id=document.getElementById("text3");
		id.style.color="red";
		id.style.fontSize="small";
		id.innerHTML="*password mismatch";
		return false;
		
		}
	}
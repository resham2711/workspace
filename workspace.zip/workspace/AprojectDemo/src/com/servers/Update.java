package com.servers;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

import oracle.jdbc.OracleTypes;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		   //  session.setAttribute("un", "ash");
		HttpSession session=request.getSession();
        String un=(String)session.getAttribute("uid");
        session.setAttribute("uid", un);
        Connection conn=DBUtil.getMyConnection();
        
        //String b=request.getParameter("b");
        
        // Statement s1=conn.createStatement();
        try{
        //if(b!=null)
        //{
            String aget=request.getParameter("aget");
            String gendert=request.getParameter("gendert");
            String cityt=request.getParameter("city");
            
           // String fn=request.getParameter("fn");
            //session.setAttribute("fn", fn);
            //out.println(photo);
           // PreparedStatement s1=conn.prepareStatement("update profile set age=?,gender=?,city=? where userid=?");
            CallableStatement s1=conn.prepareCall("call social_update_profile(?,?,?,?)");
            s1.setString(1, aget);
            s1.setString(2, gendert);
            s1.setString(3, cityt);
            s1.setString(4, un);
            int j=s1.executeUpdate();
            /*int j=s1.executeUpdate("update snusers set age='"+aget+"', gender='"+gendert+"', hobbies='"+hobbiest+"', eduq='"
                   +edut+"' where uname='"+un+"'");*/
            
            if(j==1)
                System.out.println("Data Saved successfully.");
            else
            	System.out.println("error........");
        //}
        /*String u=request.getParameter("u");
        if(u!=null)
        {
            
        }*/
        //ResultSet rs1=s1.executeQuery("select * from snusers where uname='"+un+"'");
        //PreparedStatement pp=conn.prepareStatement("select * from profile where userid=?");
            CallableStatement pp=conn.prepareCall("call social_display(?,?)");  //social_get_profile
        pp.setString(1, un);
        pp.registerOutParameter(2, OracleTypes.CURSOR);
       pp.executeQuery();
       ResultSet rs1=(ResultSet) pp.getObject(2);
        String age=null,gender=null,city=null;
        if(rs1.next())
        {
            age=rs1.getString(2);
            session.setAttribute("age", age);
            gender=rs1.getString(3);
            session.setAttribute("gender", gender);
            city=rs1.getString(4);
            session.setAttribute("city", city);
        }
	}catch(Exception e)
	{
	}
        
        RequestDispatcher rdd=request.getRequestDispatcher("home.jsp");
        rdd.forward(request, response);
        }
	}



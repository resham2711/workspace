package com.servers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

import oracle.jdbc.OracleTypes;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Register() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		 HttpSession session=request.getSession(); 
		String uid= request.getParameter("uid");
        String password = request.getParameter("passwd");
        String cpassword = request.getParameter("cpasswd");
        session.setAttribute("uid", uid);
         System.out.println("password");
        System.out.println(password);
        System.out.println(cpassword); 
        System.out.println(uid); 
        int flag = 0;
        
        
       
        
        if(password.equalsIgnoreCase(cpassword))
        { Connection con=DBUtil.getMyConnection();
       // PreparedStatement stat;
		try {
			//stat = con.prepareStatement("select userid from userd");
			CallableStatement cs=con.prepareCall("{call social_register(?)}");
			cs.registerOutParameter(1, OracleTypes.CURSOR);
			cs.executeQuery();
			ResultSet rs=(ResultSet) cs.getObject(1);
 			
	          while(rs.next())
	          {
	          
	          	if(uid.equals(rs.getString(1)))
	          	{ flag=1;
	          		
	                 out.println("<p style='color:red'>The id already exists</p>");
	                 RequestDispatcher rd1= request.getRequestDispatcher("signup.html");
	                 rd1.include(request, response);
	          	}
	          	
	          }
	          if(flag==0)
	          {
	          	 
	          	 System.out.print(uid);
	          	//PreparedStatement stat1= con.prepareStatement("insert into userd values(?,?)");
	          	 CallableStatement stat1=con.prepareCall("{call social_insert_userd(?,?)");
	          	stat1.setString(1, uid);
	          	stat1.setString(2, password);
	                   //String queryText = "insert into userd values('"+uid+"','"+password+"')";
	                   System.out.println("after query");
	                   
	                   int f= stat1.executeUpdate();
	                   
	             if(f==1)
	             	System.out.println("added in udetails");
	             else
	             	System.out.println("not added"); 
	             
	             //stat.close();
	             stat1.close();
	            
	          }
	          else
	          {
	       	   out.println("<p style='color:red'>passwords dont match.</p>");
	          
	       	   RequestDispatcher rd111= request.getRequestDispatcher("signup.html");
	              rd111.include(request, response);
	          }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //String  str="select userid from userd";
         
             RequestDispatcher rd11= request.getRequestDispatcher("profile.jsp");
             rd11.forward(request, response);
          }
         } 

        
        
        
        }
	



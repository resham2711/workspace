package com.servers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

import oracle.jdbc.OracleTypes;

/**
 * Servlet implementation class Friends
 */
@WebServlet("/Friends")
public class Friends extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Friends() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		HttpSession session=request.getSession();
		String un=(String)session.getAttribute("uid");
		Connection conn=DBUtil.getMyConnection();
		CallableStatement cs;
		try {
			cs = conn.prepareCall("{call social_friendss(?,?)}");
			cs.setString(1,un);
			cs.registerOutParameter(2, OracleTypes.CURSOR);
			cs.executeQuery();
			ResultSet rs1=(ResultSet) cs.getObject(2);

			    int i = 0;
			    boolean flag=false;
			    boolean flag1=false;
			    while (rs1.next()) {
			    	flag=true;
			        String f = rs1.getString(1);
			        /*if(f.equals(un))
			         {
			         f=rs1.getString(2);
			         }*/
			        i++;
			        out.println("<tr><td>" + i + ") " + f +"<br>");
			        out.println("<u>Mutual Friends:</u><br>");
			        /*ResultSet rs2=s.executeQuery("Select * from friends where "
			         + "(u1='"+un+"' and u2 in (select u1 from friends where u2='"+f+"' "
			         + "union select u2 from friends where u1='"+f+"'))"
			         );*/
			        //Statement s1 = conn.createStatement();
			        CallableStatement s1=conn.prepareCall("{call social_friendss1(?,?,?)}");
			        s1.setString(1, un);
			        s1.setString(2, f);
			        s1.registerOutParameter(3, OracleTypes.CURSOR);
			        cs.executeQuery();
			        ResultSet rs2 =(ResultSet) cs.getObject(3);
			        while (rs2.next()) { 
			        	flag1=true;
			            out.println(rs2.getString(1) + "<br>");
			        }
			        if(flag1==false){
                        out.println("NONE");}
			    }
			    if(flag==false){
                    out.println("no friends of " + un );}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}


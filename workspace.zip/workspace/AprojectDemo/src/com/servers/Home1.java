package com.servers;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

/**
 * Servlet implementation class Home1
 */
@WebServlet("/Home1")
public class Home1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Home1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session=request.getSession();
		String uid = (String)(session.getAttribute("uid"));
		//String username = request.getParameter("username");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String city = request.getParameter("city");
		//String username = request.getParameter("username");
		System.out.println(uid);
		System.out.println(age);
		System.out.println(gender);
		System.out.println(city);
		
		 
		 System.out.println("hello...");
		// PreparedStatement ps=null;
		 Connection conn=DBUtil.getMyConnection();
		 try {
			System.out.println("in try");
		     //ps=conn.prepareStatement("insert into profile values(?,?,?,?)");
		     CallableStatement ps=conn.prepareCall("call social_insert_profile(?,?,?,?)");
		     ps.setString(1,uid);
		     ps.setString(2,age);
		     ps.setString(3,gender);
		     ps.setString(4,city);
		     
		     System.out.println("aaa=" + age);
		     System.out.println("after query");
		     
		     int f= ps.executeUpdate();
		     
		if(f==1)
			System.out.println("added in profile");
		else
			System.out.println("not added"); 

		  
		   
		   ps.close();
		   
		   RequestDispatcher rd11= request.getRequestDispatcher("Home");
		   rd11.forward(request, response);
		  
		} catch (Exception e) {
			//response.sendRedirect("home.html");
			
		  System.err.println("SQLException: " + e.getMessage());  

		 
		   }
		 
	}

}

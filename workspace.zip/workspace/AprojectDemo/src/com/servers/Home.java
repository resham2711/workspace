package com.servers;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

import oracle.jdbc.OracleTypes;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Home() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection con=null;
		HttpSession session=request.getSession();
        try {
        	con=DBUtil.getMyConnection();
            String un=(String)(session.getAttribute("uid"));
            session.setAttribute("uid", un);
                //PreparedStatement s1=con.prepareStatement("select * from profile where userid=?");
            CallableStatement s1=con.prepareCall("{call social_display(?,?)}");
            s1.setString(1,un);
            s1.registerOutParameter(2, OracleTypes.CURSOR);
                s1.executeQuery();
                ResultSet rs2=(ResultSet) s1.getObject(2);
                String age=null,gender=null,city=null;
                if(rs2.next())
                {
                    age=rs2.getString(2);
                    session.setAttribute("age", age);
                    gender=rs2.getString(3);
                    session.setAttribute("gender", gender);
                    city=rs2.getString(4);
                    session.setAttribute("city", city);
                }
              
                s1.close();
                RequestDispatcher rd111= request.getRequestDispatcher("home.jsp");
     		   rd111.forward(request, response);
     		  
                
              } catch (Exception e) {
              	//response.sendRedirect("friends.jsp");
              	
               System.err.println("SQLException: " + e.getMessage());  


                }

}
}

package com.servers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.DBUtil;

import oracle.jdbc.OracleTypes;

/**
 * Servlet implementation class ChangePass
 */
@WebServlet("/ChangePass")
public class ChangePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String opd=request.getParameter("opd");
	try{	
Connection conn=DBUtil.getMyConnection();
HttpSession session=request.getSession();
String un=(String)(session.getAttribute("uid"));
     
//PreparedStatement s3=conn.prepareStatement("select * from userd where userid=?");
CallableStatement s3=conn.prepareCall("call social_cp(?,?)");
s3.setString(1, un);
s3.registerOutParameter(2, OracleTypes.CURSOR);
s3.executeQuery();
ResultSet rs3=(ResultSet) s3.getObject(2);
       // s3.executeQuery();
        if(rs3.next())
        {
            if(rs3.getString(2).equals(opd))
            {
                String npd=request.getParameter("npd");
                String cnpd=request.getParameter("cnpd");
                
//PreparedStatement s4=conn.prepareStatement("update userd set password=? where userid=?");
                CallableStatement s4=conn.prepareCall("{call social_update_userd(?,?)");
s4.setString(1, npd);
s4.setString(2, un);
int j=s4.executeUpdate();
                
                            if(j==1)
                            {
                                out.println("<blockquote><p style='color:green'>Password updated successfully</p></blockquote>");
                                RequestDispatcher rd=request.getRequestDispatcher("login.html");
                                rd.include(request, response);
                            }
                            else
                            {
                               out.println("<blockquote><p style='color:red'>Password not updated.</p></blockquote>");
                               RequestDispatcher rd=request.getRequestDispatcher("login.html");
                               rd.include(request, response);
                            }
                   
                }
                else
                { RequestDispatcher rd=request.getRequestDispatcher("changePass.jsp");
                rd.include(request, response);
                    out.println("<blockquote><p style='color:red'>Passwords don't match. "
                            + "Could not confirm the new password. "
                            + "Username and password not updated.</p></blockquote>");
                }
            }
            else
            {
            	RequestDispatcher rd=request.getRequestDispatcher("changePass.jsp");
                rd.include(request, response);
                out.println("<blockquote><p style='color:red'>Wrong password.</p></blockquote>");
            }
        
        
	}catch(Exception e){
		
	}
        }

	


}

import java.util.*;

public class HashMap1 {
	public static void main(String args[]) {
		HashMap<String, ArrayList<String>> hm = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		/*
		 * System.out.println("enter number of cities : "); int k =
		 * sc.nextInt();
		 */
		int k = 1;
		while (true) {
			System.out.println("enter the name of city: ");
			String city = sc.next();
			ArrayList<String> al = new ArrayList<>(); //declared inside as for each city new arraylist hona

			/*
			 * System.out.println("enter the number of trees for " + city +
			 * " :"); int n = sc.nextInt();
			 */
			int ans = 1;
			while (true) {

				System.out.println("enter the name of tree  :");
				String tname = sc.next();
				al.add(tname);
				System.out.println(" 1-->continue  0-->exit");
				ans = sc.nextInt();
				if (ans == 0) {

					break;
				}
			}
			hm.put(city, al);
			System.out.println("for city...");
			System.out.println(" 1--->continue  0-->exit");
			k = sc.nextInt();
			if (k == 0) {

				break;
			}
		}
		System.out.println("enter the city name: ");
		String c = sc.next();
		// Set<String> s = hm.keySet();
		ArrayList<String> p = hm.get(c);

		System.out.println(c);
		for (String s1 : p) {
			System.out.println(s1);

		}

	}
}

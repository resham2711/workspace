
public class AgeException extends RuntimeException
{
String message;

public AgeException(String message) {
	super(message);
	//this.message = message;
}

public AgeException() {
	super();
}

}

public class TestException
{
	public static int divide(int a,int b)
	{ try{
		return (a/b);
		}catch(Exception e)
		{
		System.out.println("b is zero");
		}
	return 0;
	}
	
public static void main(String args[])
{
	int[] numarr={34,67,56,78};
	
	
	try{
		String s="yy";
		System.out.println("length= " + s.length());
		System.out.println("division: " +		divide(10,2));	
		System.out.println("division: " +		divide(10,0));
	for(int i=0;i<numarr.length;i++) //for loop  will give error of ArrayIndexOutofBound. thus put it in try block 
	{
		System.out.println(numarr[i]);
	}
	}catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("in first catch block");
	}catch(NullPointerException e)
	{
		System.out.println("in second catch block");
		e.printStackTrace();
	}
	catch (Exception e) //if added at top then rest of catch block k idhar error aaenga
	{
		System.out.println(e.getMessage());
	}	finally{
	
		System.out.println("in finally block");
	}
}
}

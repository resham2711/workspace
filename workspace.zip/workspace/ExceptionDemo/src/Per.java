import java.util.Scanner;

public class Per {
	public static void main(String args[]){
		System.out.println("enter age:\n");
Scanner sc= new Scanner(System.in);
try{
	int age=sc.nextInt();
	if((age<18) || (age>60))
	{
		throw new AgeException("Age is invalid");
	}
}catch(AgeException e)
{
	System.out.println(e.getMessage());
}
}
}

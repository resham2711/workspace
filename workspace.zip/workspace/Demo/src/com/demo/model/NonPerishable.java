package com.demo.model;

public class NonPerishable extends Product
{

}

package com.demo.model;

public class Perishable extends Product{

}

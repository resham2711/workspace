package com.demo.service;

import java.util.Scanner;

import com.demo.model.Product;

public class User extends Product
{
	static  Product p[]=new Product[100];
	static int i=0;
 public static void addProd()
 {
	//int i=0;int id, String name, int quant, double price, String type
	 Scanner sc=new Scanner(System.in);
	int i=0;
	
		p[i]=new Product();
		System.out.println("enter the id: ");
		 int id=sc.nextInt();
		 p[i].setId(id);
		 
		 System.out.println("enter the name: ");
		 String name=sc.next();
		 p[i].setName(name);
		 
		 System.out.println("enter the quantity: ");
		 int quant=sc.nextInt();
		 p[i].setQuant(quant);
		 
		 System.out.println("enter the price: ");
		 double pri=sc.nextDouble();
		 p[i].setPrice(pri);
		 
		 System.out.println("enter the type: ");
		 String ty=sc.next();
		 p[i].setType(ty);
		 
		 i++;
	
	
	for(int j=0;j<i;j++)
	{
		System.out.println(p[j].toString());
	}
	// System.out.println("enter the details");
	 

	 
	 
 }
 public static void deleteProduct()
 {
	 
 }
 
 public static void updateProduct()
 {
	 
 }
}

package com.demo.test;

import java.util.Scanner;

import com.demo.model.Product;
import com.demo.service.User;

public class TestMain {

	public static void main(String[] args) {
		int choice = 0;
		String ans="y";
		Scanner sc = new Scanner(System.in);
		// Product p[]=new Product[100];
		 
		System.out.println("1.add product\n 2.delete product\n 3.update product\n");
		System.out.println("enter the choice: \n");
		choice = sc.nextInt();
		while(ans.equalsIgnoreCase("y"))
		{
		switch (choice) 
		{
		case 1:
			User.addProd();
			break;

		/*case 2:
			User.deleteProduct();
			break;

		case 3:
			User.updateProduct();
			break;*/

		default:
			System.out.println("enter valid option");
		}
		System.out.println("do u want to continue?");
		ans=sc.next();
		}
		System.out.println("thanku");

	}

}


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

import java.sql.*;

public class TestJdbc {

	public static void main(String[] args) {
		try {
			/*
			 * DriverManager.registerDriver(new
			 * oracle.jdbc.driver.OracleDriver());
			 * 
			 * String url = "jdbc:oracle:thin:@10.232.71.29:1521:INATP02";
			 * Connection con = DriverManager.getConnection(url, "shobana",
			 * "shobana");
			 */
			Connection con = DBUtil.getMyConnection(); // coe for connection
														// written here.
			if (con != null) {
				System.out.println("connection done");
			} else
				System.out.println("connection not done");

			Scanner sc = new Scanner(System.in);
			System.out.println("enter the id : ");
			int id = sc.nextInt();

			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);// updation
																											// will
																											// happen
																											// immediately
			Statement st1 = con.createStatement();

			ResultSet rs = st.executeQuery("select * from emp_1605 where emp_id= " + id);
			while (rs.next()) {
				System.out.println("employee id : " + rs.getInt("emp_id"));
				System.out.println("name : " + rs.getString(3));
				System.out.println("salary : " + rs.getInt(2));
			}
			// rs.first(); //runtime error if forward type result set

			System.out.println();

			/*
			 * System.out.println(rs.first());
			 * System.out.println("employee id1 : " + rs.getInt("emp_id"));
			 * System.out.println("name : " + rs.getString(3));
			 * System.out.println("salary : " + rs.getInt(2));
			 * System.out.println("---"); /*ResultSet
			 * rs1=st.executeQuery("select * from emp_1605"); while(rs1.next())
			 * { System.out.println("employee id : " + rs1.getInt("emp_id"));
			 * System.out.println("name : " + rs1.getString(3));
			 * System.out.println("salary : " + rs1.getInt(2));
			 * System.out.println(); }
			 */
			System.out.println("=-=-=-=-");
			PreparedStatement pt = con.prepareStatement("select * from emp_1605 where salary > ? ");
			pt.setInt(1, 1000);
			ResultSet rs1 = pt.executeQuery();
			while (rs1.next()) {
				System.out.println("employee id : " + rs1.getInt("emp_id"));
				System.out.println("name : " + rs1.getString(3));
				System.out.println("salary : " + rs1.getInt(2));
			}
			System.out.println("========");
			System.out.println("enter salary: ");
			int sal = sc.nextInt();
			PreparedStatement pt1 = con.prepareStatement("select * from emp_1605 where salary > ? ",
					ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			pt.setInt(1, sal);
			ResultSet rs2 = pt.executeQuery();
			while (rs2.next()) {
				System.out.println("employee id : " + rs2.getInt("emp_id"));
				System.out.println("name : " + rs2.getString(3));
				System.out.println("salary : " + rs2.getInt(2));
			}

			/*
			 * System.out.println("----insertion----"); PreparedStatement pt3 =
			 * con.prepareStatement("insert into emp_1605 values(?,?,?,?)");
			 * pt3.setInt(1, 4); pt3.setInt(2, 700); pt3.setString(3, "resh");
			 * pt3.setInt(4, 4);
			 * 
			 * int rs3 = pt3.executeUpdate(); if (rs3 > 0) {
			 * System.out.println(" insertion done"); } else
			 * System.out.println("error..........");
			 */

			System.out.println();
			System.out.println("--------search by name-----------");
			System.out.println("enter the name to search: ");
			String name = sc.next();

			PreparedStatement pt4 = con.prepareStatement("select * from emp_1605 where ename= ? ");
			pt4.setString(1, name);
			ResultSet rs4 = pt4.executeQuery();
			while (rs4.next()) {
				System.out.println("employee id : " + rs4.getInt("emp_id"));
				System.out.println("name : " + rs4.getString(3));
				System.out.println("salary : " + rs4.getInt(2));
				System.out.println(" years : " + rs4.getInt(4));
			}
			System.out.println();
			System.out.println();
			System.out.println("-----callable-----");
			CallableStatement cs = con.prepareCall("{call count_by_dept63(?,?)}");
			cs.setInt(1, 10);
			int count = 0;
			cs.registerOutParameter(2, java.sql.Types.INTEGER, count);
			cs.execute();
			count = cs.getInt(2);
			System.out.println(" count : " + count);
			System.out.println();
			CallableStatement cst = con.prepareCall("{call getUserList_56(?,?)}");
			cst.setString(1, "r");

			cst.registerOutParameter(2, OracleTypes.CURSOR);

			cst.executeUpdate();

			ResultSet rs8 = (ResultSet) cst.getObject(2);
			while (rs8.next()) {
				System.out.println("employee id : " + rs8.getInt(1));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}

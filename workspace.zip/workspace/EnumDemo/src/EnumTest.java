
public class EnumTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cofee c = Cofee.big;
		switch (c) {
		case big:
			System.out.println("you selected " + c.getSize() + " size");
			System.out.println("price: " + c.calculate());
			break;
		case small:
			System.out.println("you selected " + c.getSize() + " size");
			System.out.println("price: " + c.calculate());
			break;
		case medium:
			System.out.println("you selected " + c.getSize() + " size");
			System.out.println("price: " + c.calculate());
			break;
		default:
			System.out.println(" wrong choice");

		}
		for(Cofee c1: Cofee.values())
		{
			System.out.println(c1);
		}

	}

}

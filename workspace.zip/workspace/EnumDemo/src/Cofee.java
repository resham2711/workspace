
public enum Cofee {
big(100,20.00f),small(20,2.00f),medium(50,10.00f);
	private int size;
	private float price;
	private Cofee(int s,float p)
	{
		size=s;
		price=p;
	}
	public int getSize()
	{
		return size;
	}
	public double calculate()
	{
		return size*price;
	}
	
}

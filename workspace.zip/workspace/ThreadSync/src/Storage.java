
public class Storage {
private int num;
Boolean flag;
public Storage()
{
	num=-1;
	flag=false;
}
synchronized public void put(int x)
{
	if (flag==true)
	{
		
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	num=x;   //num  mai x product ki value daalre hai
	flag=true; 
	System.out.println("Put : " + num);
	notify(); //notify others that prod is added
}

synchronized public void get()
{
	if(flag==false)
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	System.out.println("get : " + num);
	flag=false;
	notify();
}
}

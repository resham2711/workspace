
public class PoducerConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Storage s= new Storage();
Producer p= new Producer(s);
Consumer c= new Consumer(s);
p.start();
c.start();
	}

}


public class MyClass 
{
private int num;
public MyClass(int num)
{
	this.num=num;
}
public synchronized void display(String msg){
	for(int i=0;i<num;i++)
	{
		System.out.println(msg);
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}

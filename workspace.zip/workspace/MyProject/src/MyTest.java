
public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass m=new MyClass(2);
		
		MyClass m2=new MyClass(3);
		
		//using extends
/*MyThreadDemo t=new MyThreadDemo(m,"hello");
t.start();
MyThreadDemo t1=new MyThreadDemo(m2,"welcome");
t1.start();
*/
		
		
		//using runnable
	MyThreadRun mr=new MyThreadRun(m,"hello");
	Thread th=new Thread(mr); //binding with Thread
	
	
	MyThreadRun mr2=new MyThreadRun(m,"welcome");
	Thread th2=new Thread(mr2); //binding with Thread
	th.start();
	
		//th.join();
	
	
	th2.start();
	
		//th2.join();
		
	
	
	/*MyThreadRun mr3=new MyThreadRun(m2,"hell");
	Thread th3=new Thread(mr3); //binding with Thread
	th3.start();
	*/
	}
}




public class MyThreadDemo extends Thread
{
private MyClass mc;
private String n;
public MyThreadDemo(MyClass mc,String n)
{
	this.mc=mc;
	this.n=n;
}

public void run()
{
	mc.display(n);
}
}

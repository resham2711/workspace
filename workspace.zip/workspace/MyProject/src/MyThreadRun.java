
public class MyThreadRun implements Runnable {

	private MyClass mc;
	private String n;
	public MyThreadRun(MyClass mc,String n)
	{
		this.mc=mc;
		this.n=n;
	}

	public void run()
	{
		mc.display(n);
	}

}

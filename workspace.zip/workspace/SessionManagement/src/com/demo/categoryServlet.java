package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class categoryServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException

	{
		res.setContentType("Text/html");
		PrintWriter out = res.getWriter();
		HttpSession ses = req.getSession();
		if (ses.isNew()) {
			System.out.println("new session created");
		} else {
			System.out.println("existing session retrieved");
		}

		String uname = (String) ses.getAttribute("username");
		if (uname == null) {
			System.out.println("unauthorized access...!");
		} else {
			out.println("<h1> welcome " + uname + "</h1>");
			out.println("<form>");
			out.println("<select name='course'><option value='java' " + "selected> java </option");
			out.println("<option value='.net'>.net</option>");
			out.println("<option value='c'>c</option></select>");
			out.println("</form>");
		}

	}

}

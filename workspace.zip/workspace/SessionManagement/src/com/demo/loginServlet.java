package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class loginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException

	{
		res.setContentType("Text/html");
		PrintWriter out = res.getWriter();

		HttpSession session = req.getSession();
		if (session.isNew()) {
			System.out.println("New Session created");

		} else {
			System.out.println("existing session is retrieved");

		}
		String un = req.getParameter("uname");
		session.setAttribute("username", un);
		String pass = req.getParameter("pwd");
		if ((un.equals("resham")) && (pass.equals("aa"))) {
			out.println("Success!!");
			out.println("<a href='categoryServlet'>Category Page</a>");
		} else {
			out.println("Unsuccessful");
			RequestDispatcher rd = req.getRequestDispatcher("login.html");
			rd.include(req, res);

		}
	}
}

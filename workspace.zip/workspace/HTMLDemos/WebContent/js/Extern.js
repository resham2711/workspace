/**
 * 
 */
function myfunction() {
			alert("hi,how are you? hungry?");
			document.write("<h2> ohk..go for break</h2>");
		}

		function newfunction() {
			var ans = confirm("do u want to continue?(y/n)");
			//alert("ans: " +ans)
			if(ans==true)
				{
				var num1=prompt("enter number 1");
				var num2=prompt("enter number 2");
				var num3=parseInt(num1)+parseInt(num2);
				//alert("sum is : " + num3);
				}
			else{
				alert("ohhh......ohk bye.");
			}
			
			var di=document.getElementById("divid");
			di.innerHTML="sum is : " + num3;
		}
		
		function getValue()
		{
			var str=document.getElementById("tb");
			
			var val=str.value;
			
			var di=document.getElementById("divid");
			di.innerHTML="value is : " + val;
			
		}
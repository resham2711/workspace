/**
 * 
 */

function addValue(){
	var str1=document.getElementById("num1");
var num1=str1.value;

var str2=document.getElementById("num2");
var num2=str2.value;


var sum=parseInt(num1)+parseInt(num2);
var di=document.getElementById("divid");
di.innerHTML="sum is : " + sum;
}


function subValue()
{
	var str1=document.getElementById("num1");
	var num1=str1.value;

	var str2=document.getElementById("num2");
	var num2=str2.value;

	if(num1>num2)
		{
		var sub=parseInt(num1)-parseInt(num2);
		}
	else if(num2> num1)
		{
		var sub=parseInt(num2)-parseInt(num1);
		}
	else
		{
		var sub=parseInt(num2)-parseInt(num1);
		}
	document.write("subtraction is : " + sub);
	}


function mulValue()
{
	var str1=document.getElementById("num1");
	var num1=str1.value;
	var n=parseInt(num1);
	var str="";
 //arr=new Array();
	for(var i=1;i<=10;i++)
		{
		var nump=n*i;

        str+=(n+"x"+i+"="+nump+"<br>")


		}
	var di=document.getElementById("divid");
	di.innerHTML="multiplication is : <br>" + str;
	//for(var j=1;j<arr.length;j++)
		//{
	
	//	document.write(j + "*" + num1 + "=" + arr[j] + "<br>");
		//}
	
	}

function myfunction()
{
	document.write("you pressed cancel.....");}



function myfunction1()
{
	var s=document.getElementById("tb1").value;
//	var v=s.value;
	var s2=document.getElementById("tb2").value;
	alert(s);
	alert(s2);
	//var v2=s2.value;
	if(s==s2)
		{
		  alert("ïf");
		return true;
		}
	else{
		alert("else");
		var id=document.getElementById("text2");
		id.innerHTML="no match";
		return false;
		
		
	}

}

function myConact(separator)
{
	result="";
	for(var i=1;i<arguments.length;i++)
		{
		result+=arguments[i]+separator;
		}
	//alert("hello ");
	return result;
	}
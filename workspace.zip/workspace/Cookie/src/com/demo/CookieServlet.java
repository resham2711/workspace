package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException

	{
		res.setContentType("Text/html");
		PrintWriter out = res.getWriter();
		String operation = req.getParameter("sub");
		RequestDispatcher rd = req.getRequestDispatcher("CookieLogin.html");

		if (operation.equals("add product")) {
			String pr = req.getParameter("product");
			Cookie ck = new Cookie(pr, pr);
			res.addCookie(ck);
			out.println("<h2> product added. </h2>");
			rd.include(req, res);

		} else

		{
			
			Cookie cookies[] = req.getCookies();
			for (Cookie c : cookies) {
				String val = c.getValue();
			
			out.println("<h4>" + val + "<h4>");
		}
		
		out.println("<h2> product listed. </h4>");
		rd.include(req, res);
		}
	}
}
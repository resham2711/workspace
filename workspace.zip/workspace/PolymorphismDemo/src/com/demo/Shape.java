package com.demo;

public abstract  class Shape 
{
 public abstract double area();   //added as in main ,we need to access area and perimeter method of triangle and circle in dynamic poly. thus,at compile time it will first go to the area and perimeter method of parent class i.e sh
 public abstract double perimeter();

}

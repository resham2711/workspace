package com.demo.childClasses;
import com.demo.Shape;

public class Circle extends Shape
{
	final double pi=3.142;  //constant
	private float radius;

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public Circle(float radius) {
		super();
		this.radius = radius;
	}

	public Circle() {
		super();
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
	
	public double area()
	{
		return pi * radius * radius;
	}
	
	public double perimeter()
	{
		return 2 * pi * radius;
	}
}

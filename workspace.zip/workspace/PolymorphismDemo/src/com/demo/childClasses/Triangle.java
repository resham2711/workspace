package com.demo.childClasses;

import com.demo.Shape; //without this we cannot extend triangle to shape.

public class Triangle extends Shape
{
	private int height,base;

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	//parameterized constructor
	public Triangle(int height, int base) 
	{
		super();
		this.height = height;
		this.base = base;
	}

	public Triangle()  //default constructor
	{
		super();
	}

	@Override
	public String toString() {
		return "Triangle [height=" + height + ", base=" + base + "]";
	}
	
	public double area()
	{
		return 0.5 * base * height;
	}
	
	public double perimeter()
	{
		return height+base;
	}
	
}

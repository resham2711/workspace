package com.demo.childClasses;

import com.demo.Shape;

public class Square extends Shape {
	private double side;

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	public Square(double side) {
		super();
		this.side = side;
	}

	public Square() {
		super();
	}

	@Override
	public String toString() {
		return "Square [side=" + side + "]";
	}

	public double area() {
		return side * side;
	}

	public double perimeter() {
		return side + side + side + side;
	}
}

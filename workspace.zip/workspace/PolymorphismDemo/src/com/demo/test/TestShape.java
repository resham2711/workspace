package com.demo.test;

import com.demo.childClasses.*;
import java.util.Scanner;
import com.demo.Shape;

public class TestShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String ans = "y";
		
		Shape p[]=new Shape[5];
		
		/*for(int j=0;j<p.length;j++)
		{
			p[j]=null;
		}*/
		
		int i=0;
		int t=0;
		int c=0;
		int s=0;
		int choice=0;
		int n=0;
		while (ans.equalsIgnoreCase("y") && choice !=4 && i<5)
		{

		System.out.println("1.Triangle");

		System.out.println("2.Circle");

		System.out.println("3.Square");

		System.out.println("4.Exit");

			System.out.println("choice: ");
			choice = sc.nextInt();

			//Shape s = null;
			switch (choice) {
			case 1:
				// Triangle t = new Triangle(12, 13); this is for static poly
				//s = new Triangle(12, 13);
				p[i]=new Triangle(12,13);
				//i++;
				//n++;
				break;

			case 2:
				// Circle c = new Circle(4);
				p[i] = new Circle(4);
				//i++;
				//n++;
				// System.out.println("area of circle is : " + s.area());
				break;

			case 3:
				p[i] = new Square(2);
				//i++;
				//n++;
				break;
			case 4:
				System.out.println("thank you for visiting");
				// System.exit(0);
				//n++;
				break;

			default:
				System.out.println("wrong choice");
				//n++;

			}
			i++;
			if(choice!=4){
			System.out.println("do u want to continue?");
			ans=sc.next();
			}
	
		}
		

		/*
		 * System.out.println("area of triangle  : " + s.area());
		 * System.out.println("perimeter of triangle : " + s.perimeter());
		 */// as in case 1 and case 2 same thing we are printing. this will
			// reduce the code.

		// instanceof use.
			
			for( int j=0;j<i;j++)
			{
		if (p[j] instanceof Triangle) 
		{
			System.out.println("area of triangle  : " + p[j].area());
			System.out.println();
			System.out.println("perimeter of triangle : " + p[j].perimeter());
			System.out.println();
			t++;
		} 
		else if(p[j] instanceof Circle) {
			System.out.println("area of circle  : " + p[j].area());
			System.out.println();
			System.out.println("perimeter of circle : " + p[j].perimeter());
			System.out.println();
			c++;
		}
		else
		{
			System.out.println("area of square  : " + p[j].area());
			System.out.println();
			System.out.println("perimeter of square : " + p[j].perimeter());	
			System.out.println();
			s++;
		}
		
		}
			
		System.out.println("num of triangle= " + t);
		System.out.println("num of circle= " + c);
		System.out.println("num of square= " + s);
		System.out.println("thanku");
}
}

import java.sql.Connection;
import java.sql.SQLException;

public class ProductTest {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		ProductService ps=new ProductService();
	
			
			if(DbConn.con!=null)
			{
				System.out.println("connection done..");
			}
			else
			{
				System.out.println("no connection..");
			}
			
		ps.addProduct();
		ps.display();
		/*System.out.println("enter the id to be deleted:");
Scanner sc=new Scanner()*/
		ps.delete();
		//ps.display();
		/*ps.update();
		ps.display();
		ps.delete();
		ps.display();*/
		//ps.historyDisplay();
	}

}

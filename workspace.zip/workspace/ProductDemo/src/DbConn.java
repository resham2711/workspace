import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConn {
static Connection con=null;
	
	public static Connection getMyConnection()
	{ try{
		if(con==null)
		{
			
				DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
				String url = "jdbc:oracle:thin:@10.232.71.29:1521:INATP02";
				 con = DriverManager.getConnection(url, "shobana", "shobana");
			} 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			
		}
	return con;
		
	}
}

import java.util.Date;

public class Perishable extends Product
{
private String date;

public Perishable(int id, String name, int quant, int price, String type, String date) {
	super(id, name, quant, price, type);
	this.date = date;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

}

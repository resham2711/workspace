
public class NonPerishable extends Product
{
private String category;

public NonPerishable(int id, String name, int quant, int price, String type, String category) {
	super(id, name, quant, price, type);
	this.category = category;
}
}

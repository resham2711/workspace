import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class ProductService {
	static Connection con = DbConn.getMyConnection();

	ArrayList<Product> al = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	Product p;
	Perishable pp;
	NonPerishable np;
	int ans = 1;

	public void addProduct() throws SQLException {
		while (ans == 1) {
			System.out.println("enter id: ");
			int id = sc.nextInt();
			System.out.println("enter name: ");
			String name = sc.next();
			System.out.println("enter quantity: ");
			int quant = sc.nextInt();
			System.out.println("enter price: ");
			int price = sc.nextInt();
			System.out.println("enter the type: ");
			String type = sc.next();

			if (type.equalsIgnoreCase("perishable")) {
				System.out.println("enter the expiry date: ");
				String date = sc.next();
				pp = new Perishable(id, name, quant, price, type, date);
				al.add(pp);
				/*PreparedStatement ps = null;
				ps = con.prepareStatement("insert into product_16056 values (?,?,?,?,?,?,?)");// +id,name,quant,price,type,date,"");
				ps.setInt(1, id);
				ps.setString(2, name);
				ps.setInt(3, quant);
				ps.setInt(4, price);
				ps.setString(5, type);
				ps.setString(6, date);
				ps.setString(7, null);
				int rows = ps.executeUpdate();
				if (rows > 0) {
					System.out.println("inserted...");
				} else {
					System.out.println("error...");
				}
*/
				CallableStatement pst=con.prepareCall("{call prod_add_16056(?,?,?,?,?,?,?)}");
				pst.setInt(1, id);
				pst.setString(2, name);
				pst.setInt(3, quant);
				pst.setInt(4, price);
				pst.setString(5, type);
				pst.setString(6, date);
				pst.setString(7, null);
				int rows = pst.executeUpdate();
				if (rows > 0) {
					System.out.println("inserted...");
				} else {
					System.out.println("error...");
				}
			} else if (type.equalsIgnoreCase("nonperishable")) {
				System.out.println("enter the category: ");
				String category = sc.next();
				np = new NonPerishable(id, name, quant, price, type, category);
				al.add(np);
				/*PreparedStatement ps = null;
				ps = con.prepareStatement("insert into product_16056 values (?,?,?,?,?,?,?)");// +id,name,quant,price,type,date,"");
				ps.setInt(1, id);
				ps.setString(2, name);
				ps.setInt(3, quant);
				ps.setInt(4, price);
				ps.setString(5, type);
				ps.setString(6, null);
				ps.setString(7, category);*/
				CallableStatement pst=con.prepareCall("{call prod_add_16056(?,?,?,?,?,?,?)}");
				pst.setInt(1, id);
				pst.setString(2, name);
				pst.setInt(3, quant);
				pst.setInt(4, price);
				pst.setString(5, type);
				pst.setString(6, null);
				pst.setString(7, category);
				int rows = pst.executeUpdate();
				if (rows > 0) {
					System.out.println("inserted...");
				} else {
					System.out.println("error...");
				}
			}

			System.out.println("do u want to continue adding product?.... \n Enter 1 for yes\n Enter 2 for no");
			ans = sc.nextInt();
		}
	}

	public void display() throws SQLException {
		/*
		 * for(Product i:al) { System.out.println(i); }
		 */
		CallableStatement ps1 = con.prepareCall("{call prod_display_16056(?)}");
		ps1.registerOutParameter(1, OracleTypes.CURSOR);

		// execute getDBUSERCursor store procedure

		ps1.executeUpdate();

		// get cursor and cast it to ResultSet

		ResultSet rs1 = (ResultSet) ps1.getObject(1);


		//ResultSet rs1 = ps1.executeQuery();
		while (rs1.next()) {
			System.out.println("Product id : " + rs1.getInt(1));
			System.out.println("Product name : " + rs1.getString(2));
			System.out.println("quantity : " + rs1.getInt(3));
			System.out.println("price : " + rs1.getInt(4));
			System.out.println("type : " + rs1.getString(5));
			if (rs1.getString(5).equals("perishable")) {
				System.out.println("date : " + rs1.getString(6));
				System.out.println();
			} else {
				System.out.println("category : " + rs1.getString(7));
				System.out.println();
			}
		}

	}
	
	
	public void historyDisplay() throws SQLException {
		CallableStatement ps11 = con.prepareCall("{call prod_history_display_16056(?)}");
		ps11.registerOutParameter(1, OracleTypes.CURSOR);

		// execute getDBUSERCursor store procedure

		ps11.executeUpdate();

		// get cursor and cast it to ResultSet

		ResultSet rs11 = (ResultSet) ps11.getObject(1);


		//ResultSet rs1 = ps1.executeQuery();
		while (rs11.next()) {
			System.out.println("Product id : " + rs11.getInt(1));
			System.out.println("Product name : " + rs11.getString(2));
			System.out.println("quantity : " + rs11.getInt(3));
			System.out.println("price : " + rs11.getInt(4));
			System.out.println("type : " + rs11.getString(5));
			if (rs11.getString(5).equals("perishable")) {
				System.out.println("date : " + rs11.getString(6));
				System.out.println();
			} else {
				System.out.println("category : " + rs11.getString(7));
				System.out.println();
			}
		}

	}

	public void delete() throws SQLException {
		System.out.println("enter the product id to be deleted: ");
		int id = sc.nextInt();
		
		CallableStatement cs2 = con.prepareCall("{call prod_del_16056(?)}");
		cs2.setInt(1, id);
		
		int r = cs2.executeUpdate();
		if (r > 0) {
			display();
			System.out.println("deleted..");
		} else {
			System.out.println("not deleted..");
		}
		
	}

	public void update() throws SQLException {
		int idd=0;
		String name="sdf";
		int quant =0;
		int price=0;
		System.out.println("enter the product id that you want to update..");
		int id = sc.nextInt();
		System.out.println("enter the field that you want to update..\n1.id\n2.name\n3.quantity\n4.price");
		int ans = sc.nextInt();
		CallableStatement cs3 = null;
		
		cs3=con.prepareCall("{call prod_search_16056(?)}");
		cs3.setInt(1, id);
		int num=cs3.executeUpdate();
		if(num>0){
				switch (ans) {

				case 1:
					System.out.println("enter the new id: ");
					idd=  sc.nextInt();
					cs3 = con.prepareCall("{call prod_update_16056(?,?,?,?,?,?)}");
					cs3.setInt(1, ans);
					cs3.setInt(2, idd);
					cs3.setInt(3, id);
					int r = cs3.executeUpdate();
					if (r > 0) {
						System.out.println("updated..");
					} else {
						System.out.println("not updated..");
					}
					//i.setId(idd);
					break;
				case 2:
					System.out.println("enter the new name: ");
					name= sc.next();
					cs3 = con.prepareCall("{call prod_update_16056(?,?,?)}");
					cs3.setInt(1,ans);
					cs3.setString(2, name);
					cs3.setInt(3, id);
					int r2 = cs3.executeUpdate();
					if (r2 > 0) {
						System.out.println("updated..");
						display();
					} else {
						System.out.println("not updated..");
					}
					//i.setName(name);
					break;
				case 3:
					System.out.println("enter the new quantity: ");
					quant= sc.nextInt();
					cs3 = con.prepareCall("{call prod_update_16056(?,?,?)}");
					cs3.setInt(1, ans);
					cs3.setInt(2, quant);
					cs3.setInt(3, id);
					int r3 = cs3.executeUpdate();
					if (r3 > 0) {
						System.out.println("updated..");
					} else {
						System.out.println("not updated..");
					}
					//i.setQuant(quant);
					break;
				case 4:
					System.out.println("enter the new price: ");
					price = sc.nextInt();
					cs3 = con.prepareCall("{call prod_update_16056(?,?,?)}");
					cs3.setInt(1, ans);
					cs3.setInt(2, price);
					cs3.setInt(3, id);
					int r4 = cs3.executeUpdate();
					if (r4 > 0) {
						System.out.println("updated..");
					} else {
						System.out.println("not updated..");
					}
					//i.setPrice(price);
					break;
				}
		}

			}
		//}
	//}
}

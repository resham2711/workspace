package com.demo;

public class Product {

	private int pid;
	private String pname;
	private double prate;
	private int quant;
	public Product(int pid, String pname, double prate, int quant) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.prate = prate;
		this.quant = quant;
	}
	public Product() {
		super();
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrate() {
		return prate;
	}
	public void setPrate(double prate) {
		this.prate = prate;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	
}

import java.io.*;
import java.net.*;

public class MyServer {
public static void main(String args[])
{
	try {
		
		ServerSocket ss= new ServerSocket(6868);
		Socket s=ss.accept();
		DataInputStream dis=new DataInputStream(s.getInputStream());
		DataOutputStream dos=new DataOutputStream(s.getOutputStream()); 
		
		System.out.println("connection established............");
		String str="",str2="";
		String id=""  ,name=" " , sal="" ;
		FileInputStream fis=null;
		if(id!=null)
		{
			id=dis.readUTF();
			System.out.println("got id" + id);
		}
			fis=new FileInputStream("C:\\Users\\XBBNLJ4\\Desktop\\hello.txt");    //opening the file
			BufferedReader br=new BufferedReader(new InputStreamReader(fis));
			String data=br.readLine();
			String arr[]=data.split(",");
			for(int i=0;i<arr.length;i++)
			{
				if(id.equals(arr[i]))
				{
					System.out.println("found id");
					System.out.println(arr[i+1]);
					System.out.println(arr[i+2]);
					name=arr[i+1];
					sal=arr[i+2];
					dos.writeUTF(name);
					dos.writeUTF(sal);
					break;
				}
				else
					System.out.println("not found");
			}
		
		/*dis.close();
		s.close();
		ss.close();*/
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}

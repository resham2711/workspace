import java.io.Serializable;

public class Emp implements Serializable
{
String id;
String name;
String sal;

public Emp(String id,String name,String sal)
{
	this.id=id;
	this.name=name;
	this.sal=sal;
}
public Emp(String name,String sal)
{
	this.name=name;
	this.sal=sal;
}
}

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThreadClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Socket s;
		 DataOutputStream ds=null;
		 DataInputStream dos=null;
		try {
			s = new Socket("localhost",5995);
			ds=new DataOutputStream(s.getOutputStream());
			dos=new DataInputStream(s.getInputStream());
			 Scanner sc=new Scanner(System.in);
			 System.out.println("Enter Number of clients...");
		        int x=sc.nextInt();
		        ThreadDemo a1;
		        for(int i=0;i<x;i++)
		        {
		a1= new ThreadDemo(ds,dos);
		        a1.start();
		        }
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	       
	       
	        
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThreadServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Socket s;
        ServerSocket a1;
        DataOutputStream ds=null;
        DataInputStream dos=null;
		try {
			a1 = new ServerSocket(5995);
			s=a1.accept();
	         ds=new DataOutputStream(s.getOutputStream());
	        dos=new DataInputStream(s.getInputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        while(true)
               
               
        {
               try
               
               {
 FileReader fr=new FileReader(new File("C:\\Users\\XBBNLJ4\\Desktop\\abc.txt"));
        BufferedReader br=new BufferedReader(fr);

        String str=dos.readUTF();
        System.out.println(str);
        Pattern p=Pattern.compile(str);
 String qw=    br.readLine();
 System.out.println(qw);
 
        while(qw!=null)
        {
               Matcher m=p.matcher(qw);

 
        
        if((m.find()))
               
        {
               
               ds.writeBoolean(true);
               break;
               
               
        }
        else
        {
               ds.writeBoolean(false);
        }
        qw=    br.readLine();
        }
        
 }
 catch(Exception e)
 {
        
 }
        }



	}

}

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ThreadDemo extends Thread{
	private DataOutputStream ds;
    private DataInputStream dos;
    public ThreadDemo( DataOutputStream ds,DataInputStream dos)
    {
    this.ds=ds;
    this.dos=dos;
    }
    public void run()
    {
                    Scanner sc=new Scanner(System.in);
                    System.out.println("Enter the string to search");
                    try {
                    	String s=sc.next();
						ds.writeUTF(s);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
    try {
                    System.out.println(        dos.readBoolean());
    } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
    }


    }
}

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;
import java.util.Scanner;

public class MyClient
{
public static void main(String args[])
{
	try {
		Socket s= new Socket("localhost",6868);
		String str="",str2="",name="",sal="";
		DataInputStream cin=new DataInputStream(s.getInputStream());
		DataOutputStream cout=new DataOutputStream(s.getOutputStream());
		FileOutputStream fos=null;
		FileInputStream fis=null;
		ObjectOutputStream oo=null;
		ObjectInputStream ois=null;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		/*while(!str.equalsIgnoreCase("stop"))
		{
			str2=br.readLine();
			cout.writeUTF(str2);
			str=cin.readUTF();
			System.out.println("Server : " + str);
		}*/
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the id to search: ");
		String id=sc.next();
		cout.writeUTF(id);
		if(name!=null && sal!=null)
		{
			name=cin.readUTF();
			sal=cin.readUTF();
			Emp e=new Emp(name,sal);
			fos=new FileOutputStream("C:\\Users\\XBBNLJ4\\Desktop\\emp.txt");
			oo=new ObjectOutputStream(fos);
			oo.writeObject(e);
			
			fis=new FileInputStream("C:\\Users\\XBBNLJ4\\Desktop\\emp.txt");
			ois=new ObjectInputStream(fis);
			
			/*try {
				System.out.println(" "+ (Emp)ois.readObject());
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
			System.out.println(name);
			System.out.println(sal);
		}
	} catch (UnknownHostException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}

package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UrlRewriting extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException

	{
		res.setContentType("Text/html");
		PrintWriter out = res.getWriter();

		String count = req.getParameter("count");
		int cnt = Integer.parseInt(count);
		cnt++;
		out.println("<h2> hit count: " + cnt + "</h2>");
		out.println("<a href='UrlRewriting?count=" + cnt + "'>click here</a>");
		out.close();

	}
}

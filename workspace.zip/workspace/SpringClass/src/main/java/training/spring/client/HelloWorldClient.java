package training.spring.client;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import training.spring.HelloWorld;

public class HelloWorldClient {

	public static void main(String[] args) {
		
        XmlBeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("HelloWorld.xml"));

        HelloWorld bean=(HelloWorld) beanFactory.getBean("HWBean");
       /* HelloWorld bean1=(HelloWorld) beanFactory.getBean("HWBean1");
        HelloWorld bean2=(HelloWorld) beanFactory.getBean("HWBean2");*/
                        bean.sayHello();
                        System.out.println(bean.getMsg());
                        /*bean1.sayHello();
                        bean2.sayHello();*/

}


	}



package training.spring;

public class MyMessage {
private int msgid;
private String message;

public int getMsgid() {
	return msgid;
}
public void setMsgid(int msgid) {
	this.msgid = msgid;
}
public String getMessage() {
	return message;
}
@Override
public String toString() {
	return "MyMessage [msgid=" + msgid + ", message=" + message + "]";
}
public void setMessage(String message) {
	this.message = message;
}

}

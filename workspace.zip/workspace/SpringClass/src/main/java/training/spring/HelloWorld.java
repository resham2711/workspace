package training.spring;

public class HelloWorld {
	private int id;
	private String msg;
	private MyMessage myMsg;
	
	
	

public MyMessage getMyMsg() {
		return myMsg;
	}
	public void setMyMsg(MyMessage myMsg) {
		this.myMsg = myMsg;
	}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}


public HelloWorld() {
	super();
	System.out.println("in constructor");
}
public HelloWorld(int id, String msg) {
	
	this.id = id;
	this.msg = msg;
}
public void sayHello()
{
	System.out.println("hello spring");
	System.out.println(id);
	System.out.println(msg);
}

}
